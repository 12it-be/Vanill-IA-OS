<?php

declare(strict_types=1);

require_once __DIR__ . '/api/bootstrap.php';

vanillia_start_session(false);
$csrfToken = vanillia_csrf_token();
$osName = vanillia_get_setting('os.name', 'Vanill-IA OS');

header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
?>
<!DOCTYPE html>
<html lang="fr" data-theme="dark" data-wallpaper="aurora-coral">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
  <meta name="csrf-token" content="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
  <meta name="theme-color" content="#0F1115">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <meta name="apple-mobile-web-app-title" content="Vanill-IA OS">
  <meta name="application-name" content="Vanill-IA OS">

  <title><?= htmlspecialchars($osName, ENT_QUOTES, 'UTF-8') ?></title>

  <link rel="manifest" href="/manifest.json">
  <link rel="icon" type="image/svg+xml" href="/assets/img/icons/logo.svg">
  <link rel="icon" type="image/png" sizes="32x32" href="/assets/img/pwa/favicon-32.png">
  <link rel="apple-touch-icon" sizes="180x180" href="/assets/img/pwa/apple-touch-icon.png">
  <link rel="stylesheet" href="/assets/css/desktop.css">
</head>
<body>
  <!-- Fond d'écran Mesh GPU -->
  <div class="os-wallpaper" aria-hidden="true"></div>

  <!-- Couche Setup Wizard / Connexion -->
  <main id="authLayer" class="auth-layer hidden"></main>

  <!-- Surcouche Écran Verrouillé façon Synology DSM (préserve les fenêtres ouvertes) -->
  <aside id="lockLayer" class="lock-layer hidden"></aside>

  <!-- Barre Supérieure Fine (macOS / Synology DSM) -->
  <header id="osTopbar" class="os-topbar hidden">
    <div class="topbar-left">
      <button type="button" id="launcherMenuBtn" class="topbar-btn" title="Menu Applications (Ctrl+K)">
        <img src="/assets/img/icons/logo.svg" alt="Vanill-IA" class="topbar-logo">
        <strong>Vanill-IA OS</strong>
      </button>
      <span id="activeAppTitle" class="topbar-active-app hide-mobile">Bureau</span>
    </div>

    <button type="button" id="spotlightTriggerBtn" class="topbar-spotlight-trigger hide-mobile">
      <span>Rechercher une app ou action...</span>
      <kbd>Ctrl K</kbd>
    </button>

    <div class="topbar-right">
      <button type="button" id="pwaInstallBtn" class="topbar-btn hidden" title="Installer l'application PWA">
        <span style="color:var(--os-accent);font-weight:700;">+ Installer l'App</span>
      </button>

      <button type="button" id="topbarMetricsBtn" class="topbar-btn hide-mobile" style="padding:0 4px;" title="Ouvrir le Moniteur de Ressources">
        <span class="metric-pill">
          <span>CPU</span>
          <span class="metric-bar"><span id="topbarCpuBar" style="width:0%"></span></span>
          <span id="topbarCpuText">--%</span>
        </span>
        <span class="metric-pill">
          <span>RAM</span>
          <span class="metric-bar"><span id="topbarRamBar" style="width:0%"></span></span>
          <span id="topbarRamText">--%</span>
        </span>
      </button>

      <button type="button" id="themeSwitchBtn" class="topbar-btn" title="Basculer Mode Sombre / Clair">◐</button>

      <button type="button" id="notifToggleBtn" class="topbar-btn" title="Centre de notifications">
        <span>🔔</span>
        <span id="notifBadge" class="notif-badge hidden">0</span>
      </button>

      <span id="topbarClock" class="topbar-btn hide-mobile" style="cursor:default;font-variant-numeric:tabular-nums;">--:--</span>

      <button type="button" id="powerMenuBtn" class="topbar-btn" title="Session, Verrouillage & Alimentation">⏻</button>
    </div>
  </header>

  <!-- Espace de Travail du Bureau & Moteur Multi-Fenêtres -->
  <div id="osDesktop" class="os-desktop hidden">
    <div id="mobileHeroCard" class="mobile-hero-card"></div>
    <div id="desktopIconsGrid" class="desktop-icons-grid"></div>
    <div id="windowsLayer" class="windows-layer"></div>
  </div>

  <!-- Aperçu Magnétique Aero-Snap -->
  <div id="snapPreview" class="snap-preview hidden"></div>

  <!-- Dock Flottant Inférieur (umbrelOS / macOS) -->
  <nav id="osDockWrap" class="os-dock-wrap hidden" aria-label="Dock Applications">
    <div id="osDock" class="os-dock"></div>
  </nav>

  <!-- Barre de Navigation Tactile Mobile (Mode App Launcher < 860px) -->
  <nav id="mobileTaskbar" class="mobile-taskbar hidden" aria-label="Navigation Mobile">
    <button type="button" id="mobHomeBtn" class="mobile-nav-btn active">
      <span>⊞</span>
      <span>Applications</span>
    </button>
    <button type="button" id="mobSearchBtn" class="mobile-nav-btn">
      <span>⌕</span>
      <span>Recherche</span>
    </button>
    <button type="button" id="mobLockBtn" class="mobile-nav-btn">
      <span>🔒</span>
      <span>Verrouiller</span>
    </button>
  </nav>

  <!-- Palette Rapide Spotlight (Ctrl+K) -->
  <div id="spotlightBackdrop" class="spotlight-backdrop hidden">
    <div class="spotlight-modal">
      <div class="spotlight-search-row">
        <span style="color:var(--os-accent);font-weight:700;">⌕</span>
        <input type="text" id="spotlightInput" class="spotlight-input" placeholder="Lancer un module système, conteneur Docker ou panneau..." autocomplete="off">
      </div>
      <div id="spotlightResults" class="spotlight-results"></div>
    </div>
  </div>

  <!-- Tiroir du Centre de Notifications -->
  <aside id="notifDrawer" class="notif-drawer hidden">
    <div class="drawer-header">
      <strong>Notifications Système</strong>
      <div style="display:flex;gap:8px;">
        <button type="button" id="markAllReadBtn" style="font-size:0.75rem;color:var(--os-accent);">Tout lire</button>
        <button type="button" id="clearNotifsBtn" style="font-size:0.75rem;color:var(--os-text-secondary);">Vider</button>
      </div>
    </div>
    <div id="notifList" class="drawer-list"></div>
  </aside>

  <!-- Menu Alimentation & Verrouillage Session -->
  <div id="powerPopover" class="power-popover hidden">
    <button type="button" class="ctx-item" data-power="settings">Sécurité 2FA & Apparence</button>
    <button type="button" class="ctx-item" data-power="lock">Verrouiller l'écran (DSM)</button>
    <button type="button" class="ctx-item" data-power="logout">Fermer la session</button>
    <div class="ctx-sep"></div>
    <button type="button" class="ctx-item" data-power="reboot">Redémarrer Debian</button>
    <button type="button" class="ctx-item danger" data-power="poweroff">Éteindre le serveur</button>
  </div>

  <!-- Menu Contextuel Clic Droit -->
  <div id="contextMenu" class="context-menu hidden"></div>

  <!-- Pile de Notifications Toast -->
  <div id="toastStack" class="toast-stack"></div>

  <script type="module" src="/assets/js/core/Desktop.js"></script>
</body>
</html>
