/**
 * ==============================================================================
 * Vanill-IA OS — Hybrid Desktop, Auth, DSM Lock, Spotlight & PWA Controller
 * ==============================================================================
 */

import { api } from './ApiClient.js';
import { renderQrCodeSvg } from './QrCode.js';
import { WindowManager, getAppIconSvg } from './WindowManager.js';

class VanillIADesktop {
  constructor() {
    this.state = {
      authenticated: false,
      locked: false,
      setupRequired: false,
      requiresSetupToken: false,
      isLocalNetwork: true,
      user: null,
      os: {},
      shortcuts: [],
      pulseTimer: null,
      clockTimer: null,
      deferredInstallPrompt: null,
    };

    this.els = {
      authLayer: document.getElementById('authLayer'),
      lockLayer: document.getElementById('lockLayer'),
      topbar: document.getElementById('osTopbar'),
      desktop: document.getElementById('osDesktop'),
      iconsGrid: document.getElementById('desktopIconsGrid'),
      windowsLayer: document.getElementById('windowsLayer'),
      snapPreview: document.getElementById('snapPreview'),
      dockWrap: document.getElementById('osDockWrap'),
      dock: document.getElementById('osDock'),
      mobileHero: document.getElementById('mobileHeroCard'),
      mobileTaskbar: document.getElementById('mobileTaskbar'),
      spotlightBackdrop: document.getElementById('spotlightBackdrop'),
      spotlightInput: document.getElementById('spotlightInput'),
      spotlightResults: document.getElementById('spotlightResults'),
      notifDrawer: document.getElementById('notifDrawer'),
      notifList: document.getElementById('notifList'),
      notifBadge: document.getElementById('notifBadge'),
      powerPopover: document.getElementById('powerPopover'),
      contextMenu: document.getElementById('contextMenu'),
      toastStack: document.getElementById('toastStack'),
      activeAppTitle: document.getElementById('activeAppTitle'),
      cpuText: document.getElementById('topbarCpuText'),
      cpuBar: document.getElementById('topbarCpuBar'),
      ramText: document.getElementById('topbarRamText'),
      ramBar: document.getElementById('topbarRamBar'),
      clockText: document.getElementById('topbarClock'),
      pwaInstallBtn: document.getElementById('pwaInstallBtn'),
    };

    this.wm = new WindowManager({
      containerEl: this.els.windowsLayer,
      snapPreviewEl: this.els.snapPreview,
      onStateChange: (winState) => this.onWindowsStateChanged(winState),
    });
  }

  async init() {
    this.registerPwaLifecycle();
    this.bindGlobalEvents();
    this.startClock();

    try {
      const status = await api.get('/api/auth.php?action=status');
      this.state.setupRequired = Boolean(status.setup_required);
      this.state.requiresSetupToken = Boolean(status.requires_setup_token);
      this.state.isLocalNetwork = Boolean(status.is_local_network);
      this.state.authenticated = Boolean(status.authenticated);
      this.state.locked = Boolean(status.locked);
      this.state.user = status.user || null;
      this.state.os = status.os || {};

      if (this.state.setupRequired) {
        this.renderSetupWizard();
        return;
      }

      if (!this.state.authenticated) {
        this.renderLoginScreen();
        return;
      }

      await this.enterDesktop();
      if (this.state.locked) {
        this.showLockScreen();
      }
    } catch (err) {
      this.toast(err.message || 'Erreur lors du chargement initial.', 'error');
    }
  }

  registerPwaLifecycle() {
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js', { scope: '/' }).catch(() => {});
      });
    }

    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      this.state.deferredInstallPrompt = e;
      this.els.pwaInstallBtn?.classList.remove('hidden');
    });

    window.addEventListener('appinstalled', () => {
      this.state.deferredInstallPrompt = null;
      this.els.pwaInstallBtn?.classList.add('hidden');
      this.toast('Vanill-IA OS est installé en mode application native !');
    });

    this.els.pwaInstallBtn?.addEventListener('click', async () => {
      if (this.state.deferredInstallPrompt) {
        this.state.deferredInstallPrompt.prompt();
        await this.state.deferredInstallPrompt.userChoice;
        this.state.deferredInstallPrompt = null;
        this.els.pwaInstallBtn.classList.add('hidden');
      } else {
        this.toast('Sur iOS Safari : touchez Partager puis "Sur l\'écran d\'accueil".');
      }
    });
  }

  bindGlobalEvents() {
    window.addEventListener('vanillia:session-locked', () => {
      if (this.state.authenticated) {
        this.state.locked = true;
        this.showLockScreen();
      }
    });

    window.addEventListener('vanillia:auth-expired', () => {
      this.stopPulse();
      this.state.authenticated = false;
      this.renderLoginScreen();
    });

    // Raccourcis globaux (Ctrl+K / Cmd+K Spotlight, Escape fermeture overlays)
    window.addEventListener('keydown', (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k' && this.state.authenticated && !this.state.locked) {
        e.preventDefault();
        this.toggleSpotlight();
      } else if (e.key === 'Escape') {
        this.closeFloatingPanels();
      }
    });

    document.addEventListener('click', (e) => {
      if (!e.target.closest('#contextMenu')) {
        this.els.contextMenu.classList.add('hidden');
      }
      if (!e.target.closest('#powerPopover') && !e.target.closest('#powerMenuBtn')) {
        this.els.powerPopover.classList.add('hidden');
      }
      if (!e.target.closest('#notifDrawer') && !e.target.closest('#notifToggleBtn')) {
        this.els.notifDrawer.classList.add('hidden');
      }
    });

    // Menu contextuel clic droit sur le fond du bureau
    this.els.desktop.addEventListener('contextmenu', (e) => {
      if (e.target.closest('.os-window')) return;
      e.preventDefault();
      const iconItem = e.target.closest('.desktop-icon-item');
      const appId = iconItem ? iconItem.dataset.appId : null;
      this.openContextMenu(e.clientX, e.clientY, appId);
    });

    // Topbar actions
    document.getElementById('launcherMenuBtn')?.addEventListener('click', () => this.toggleSpotlight());
    document.getElementById('spotlightTriggerBtn')?.addEventListener('click', () => this.toggleSpotlight());
    document.getElementById('topbarMetricsBtn')?.addEventListener('click', () => this.launchAppById('resource-monitor'));

    document.getElementById('themeSwitchBtn')?.addEventListener('click', async () => {
      const next = (this.state.user?.theme_mode || 'dark') === 'dark' ? 'light' : 'dark';
      try {
        const res = await api.post('/api/auth.php?action=preferences', { theme_mode: next });
        this.applyUserPreferences(res.user);
      } catch (err) {
        this.toast(err.message, 'error');
      }
    });

    document.getElementById('notifToggleBtn')?.addEventListener('click', () => this.toggleNotificationsDrawer());
    document.getElementById('markAllReadBtn')?.addEventListener('click', async () => {
      await api.post('/api/system.php?action=notifications_read');
      this.els.notifBadge.classList.add('hidden');
      this.loadNotifications();
    });
    document.getElementById('clearNotifsBtn')?.addEventListener('click', async () => {
      await api.post('/api/system.php?action=notifications_clear');
      this.els.notifBadge.classList.add('hidden');
      this.loadNotifications();
    });

    document.getElementById('powerMenuBtn')?.addEventListener('click', () => {
      this.els.powerPopover.classList.toggle('hidden');
    });

    this.els.powerPopover.addEventListener('click', async (e) => {
      const btn = e.target.closest('[data-power]');
      if (!btn) return;
      const act = btn.dataset.power;
      this.els.powerPopover.classList.add('hidden');

      if (act === 'lock') {
        await api.post('/api/auth.php?action=lock');
        this.state.locked = true;
        this.showLockScreen();
      } else if (act === 'settings') {
        this.launchAppById('system-settings');
      } else if (act === 'logout') {
        await api.post('/api/auth.php?action=logout');
        this.stopPulse();
        this.state.authenticated = false;
        this.renderLoginScreen();
      } else if (act === 'reboot' || act === 'poweroff') {
        const label = act === 'reboot' ? 'redémarrer' : 'éteindre';
        if (window.confirm(`Confirmez-vous vouloir ${label} le serveur Debian ?`)) {
          try {
            await api.post('/api/system.php?action=power', { mode: act });
            if (act === 'reboot') {
              window.location.href = '/offline.html';
            } else {
              this.toast('Extinction du serveur Debian programmée dans 2 secondes.');
            }
          } catch (err) {
            this.toast(err.message, 'error');
          }
        }
      }
    });

    // Spotlight filtre temps réel
    this.els.spotlightBackdrop.addEventListener('click', (e) => {
      if (e.target === this.els.spotlightBackdrop) {
        this.els.spotlightBackdrop.classList.add('hidden');
      }
    });
    this.els.spotlightInput.addEventListener('input', () => {
      this.renderSpotlightItems(this.els.spotlightInput.value);
    });
    this.els.spotlightInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        const first = this.els.spotlightResults.querySelector('.spotlight-item');
        if (first) first.click();
      }
    });

    // Barre mobile basse
    document.getElementById('mobHomeBtn')?.addEventListener('click', () => this.wm.minimizeAll());
    document.getElementById('mobSearchBtn')?.addEventListener('click', () => this.toggleSpotlight());
    document.getElementById('mobLockBtn')?.addEventListener('click', async () => {
      await api.post('/api/auth.php?action=lock');
      this.state.locked = true;
      this.showLockScreen();
    });
  }

  closeFloatingPanels() {
    this.els.spotlightBackdrop.classList.add('hidden');
    this.els.notifDrawer.classList.add('hidden');
    this.els.powerPopover.classList.add('hidden');
    this.els.contextMenu.classList.add('hidden');
  }

  // ==========================================================================
  // 1. PREMIER LANCEMENT : SETUP WIZARD SÉCURISÉ (ZÉRO MOT DE PASSE PAR DÉFAUT)
  // ==========================================================================

  renderSetupWizard() {
    this.hideDesktopChrome();
    this.els.authLayer.classList.remove('hidden');

    const tokenNotice = this.state.requiresSetupToken
      ? `<div class="os-alert os-alert-info">Connexion détectée depuis une IP externe. Renseignez le jeton affiché lors de l'installation (ou via <code>sudo vanill-ia-os setup-token</code>).</div>`
      : `<div class="os-alert os-alert-info">Réseau local / Tailscale détecté. Créez votre compte administrateur unique (la route d'initialisation se verrouillera aussitôt).</div>`;

    this.els.authLayer.innerHTML = `
      <div class="auth-card setup-wide">
        <div class="brand-header">
          <img src="/assets/img/icons/logo.svg" alt="Vanill-IA OS" class="brand-logo">
          <h1>Initialisation de Vanill-IA OS</h1>
          <p>Configuration sécurisée du premier démarrage (Argon2id + 2FA TOTP)</p>
        </div>

        <div id="setupError" class="os-alert os-alert-error hidden"></div>
        ${tokenNotice}

        <form id="setupForm" autocomplete="off">
          <div class="form-group ${this.state.requiresSetupToken ? '' : 'hidden'}" id="setupTokenWrap">
            <label class="form-label">Jeton d'installation (Setup Token)</label>
            <input type="text" class="os-input" name="setup_token" placeholder="Ex: A1B2C3D4E5F6..." style="font-family:var(--font-mono);">
          </div>

          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
            <div class="form-group">
              <label class="form-label">Identifiant Admin</label>
              <input type="text" class="os-input" name="username" value="admin" required minlength="3" maxlength="32">
            </div>
            <div class="form-group">
              <label class="form-label">Nom affiché</label>
              <input type="text" class="os-input" name="display_name" value="Administrateur" required>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Mot de passe fort (10 caractères min.)</label>
            <input type="password" class="os-input" name="password" required minlength="10" placeholder="••••••••••••">
          </div>

          <div class="form-group">
            <label style="display:flex;align-items:center;gap:9px;cursor:pointer;font-size:0.86rem;font-weight:600;">
              <input type="checkbox" id="setupEnableTotp">
              Activer immédiatement la double authentification 2FA (TOTP)
            </label>
            <div id="setupTotpPanel" class="totp-setup-box hidden"></div>
          </div>

          <button type="submit" class="os-btn os-btn-primary">Créer l'administrateur et verrouiller le Setup</button>
        </form>
      </div>
    `;

    const form = this.els.authLayer.querySelector('#setupForm');
    const errBox = this.els.authLayer.querySelector('#setupError');
    const totpCheck = this.els.authLayer.querySelector('#setupEnableTotp');
    const totpPanel = this.els.authLayer.querySelector('#setupTotpPanel');

    totpCheck.addEventListener('change', async () => {
      if (!totpCheck.checked) {
        totpPanel.classList.add('hidden');
        totpPanel.innerHTML = '';
        return;
      }
      try {
        const username = form.elements.username.value.trim() || 'admin';
        const prep = await api.post('/api/auth.php?action=setup_prepare_totp', { username });
        const svg = renderQrCodeSvg(prep.otpauth_uri);
        totpPanel.classList.remove('hidden');
        totpPanel.innerHTML = `
          <div class="qr-frame">${svg}</div>
          <p style="text-align:center;font-family:var(--font-mono);font-size:0.76rem;margin-bottom:10px;" class="selectable">Secret : ${prep.secret}</p>
          <input type="text" class="os-input code-totp" name="totp_code" placeholder="000000" maxlength="6" inputmode="numeric">
        `;
      } catch (err) {
        errBox.textContent = err.message;
        errBox.classList.remove('hidden');
        totpCheck.checked = false;
      }
    });

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      errBox.classList.add('hidden');
      const fd = new FormData(form);

      try {
        const res = await api.post('/api/auth.php?action=setup', {
          setup_token: fd.get('setup_token') || '',
          username: fd.get('username'),
          display_name: fd.get('display_name'),
          password: fd.get('password'),
          enable_totp: totpCheck.checked,
          totp_code: fd.get('totp_code') || '',
        });

        this.state.setupRequired = false;
        this.state.authenticated = true;
        this.state.locked = false;
        this.state.user = res.user;

        if (Array.isArray(res.backup_codes) && res.backup_codes.length > 0) {
          this.renderBackupCodesInterstitial(res.backup_codes);
        } else {
          await this.enterDesktop();
        }
      } catch (err) {
        errBox.textContent = err.message;
        errBox.classList.remove('hidden');
        if (err.code === 'INVALID_SETUP_TOKEN') {
          this.els.authLayer.querySelector('#setupTokenWrap')?.classList.remove('hidden');
        }
      }
    });
  }

  renderBackupCodesInterstitial(codes) {
    this.els.authLayer.innerHTML = `
      <div class="auth-card">
        <div class="brand-header">
          <img src="/assets/img/icons/logo.svg" alt="Vanill-IA OS" class="brand-logo">
          <h1>Codes de secours 2FA</h1>
          <p>Conservez ces 8 codes hors ligne. Chacun permet une connexion d'urgence unique.</p>
        </div>
        <div class="backup-codes-grid selectable">
          ${codes.map((c) => `<div class="backup-code-chip">${c}</div>`).join('')}
        </div>
        <button type="button" class="os-btn os-btn-primary" id="continueToOsBtn">J'ai copié mes codes — Ouvrir Vanill-IA OS</button>
      </div>
    `;
    this.els.authLayer.querySelector('#continueToOsBtn').addEventListener('click', () => {
      this.enterDesktop();
    });
  }

  // ==========================================================================
  // 2. ÉCRAN DE CONNEXION (LOGIN + CHALLENGE 2FA TOTP)
  // ==========================================================================

  renderLoginScreen() {
    this.hideDesktopChrome();
    this.els.lockLayer.classList.add('hidden');
    this.els.authLayer.classList.remove('hidden');

    this.els.authLayer.innerHTML = `
      <div class="auth-card">
        <div class="brand-header">
          <img src="/assets/img/icons/logo.svg" alt="Vanill-IA OS" class="brand-logo">
          <h1>Vanill-IA OS</h1>
          <p>${this.state.os.hostname ? `Serveur ${this.state.os.hostname}` : 'Connexion sécurisée au WebOS'}</p>
        </div>

        <div id="loginError" class="os-alert os-alert-error hidden"></div>

        <form id="loginForm">
          <div id="credentialsStep">
            <div class="form-group">
              <label class="form-label">Identifiant</label>
              <input type="text" class="os-input" name="username" autocomplete="username" required autofocus>
            </div>
            <div class="form-group">
              <label class="form-label">Mot de passe</label>
              <input type="password" class="os-input" name="password" autocomplete="current-password" required>
            </div>
          </div>

          <div id="totpStep" class="hidden">
            <div class="os-alert os-alert-info">Saisissez le code à 6 chiffres de votre application 2FA (ou un code de secours).</div>
            <div class="form-group">
              <input type="text" class="os-input code-totp" name="totp_code" placeholder="000000" maxlength="9" autocomplete="one-time-code">
            </div>
          </div>

          <button type="submit" class="os-btn os-btn-primary" id="loginSubmitBtn">Se connecter</button>
        </form>
      </div>
    `;

    const form = this.els.authLayer.querySelector('#loginForm');
    const errBox = this.els.authLayer.querySelector('#loginError');
    const credStep = this.els.authLayer.querySelector('#credentialsStep');
    const totpStep = this.els.authLayer.querySelector('#totpStep');

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      errBox.classList.add('hidden');
      const fd = new FormData(form);

      try {
        const res = await api.post('/api/auth.php?action=login', {
          username: fd.get('username'),
          password: fd.get('password'),
          totp_code: fd.get('totp_code') || '',
        });

        if (res.totp_required) {
          credStep.classList.add('hidden');
          totpStep.classList.remove('hidden');
          totpStep.querySelector('input')?.focus();
          return;
        }

        this.state.authenticated = true;
        this.state.locked = false;
        this.state.user = res.user;
        await this.enterDesktop();
      } catch (err) {
        errBox.textContent = err.message;
        errBox.classList.remove('hidden');
      }
    });
  }

  // ==========================================================================
  // 3. ÉCRAN DE VERROUILLAGE FAÇON SYNOLOGY DSM (PRÉSERVE LES FENÊTRES)
  // ==========================================================================

  showLockScreen() {
    this.closeFloatingPanels();
    this.els.lockLayer.classList.remove('hidden');
    const user = this.state.user || {};
    const now = new Date();

    this.els.lockLayer.innerHTML = `
      <div>
        <div class="lock-clock" id="lockClockDigits">${now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}</div>
        <div class="lock-date">${now.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' })}</div>

        <div class="auth-card">
          <div class="brand-header" style="margin-bottom:18px;">
            <img src="/assets/img/icons/logo.svg" alt="Vanill-IA OS" class="brand-logo" style="width:52px;height:52px;">
            <h1>Session verrouillée</h1>
            <p>${user.display_name || user.username || 'Administrateur'} (@${user.username || 'admin'})</p>
          </div>

          <div id="unlockError" class="os-alert os-alert-error hidden"></div>

          <form id="unlockForm">
            <div class="form-group">
              <label class="form-label">Mot de passe pour reprendre la session</label>
              <input type="password" class="os-input" name="password" required autofocus>
            </div>
            ${user.totp_enabled ? `
              <div class="form-group">
                <label class="form-label">Code 2FA TOTP</label>
                <input type="text" class="os-input code-totp" name="totp_code" placeholder="000000" maxlength="9" required>
              </div>
            ` : ''}
            <button type="submit" class="os-btn os-btn-primary">Déverrouiller le bureau</button>
            <button type="button" class="os-btn os-btn-ghost" id="switchUserBtn" style="width:100%;margin-top:8px;">Fermer la session</button>
          </form>
        </div>
      </div>
    `;

    const form = this.els.lockLayer.querySelector('#unlockForm');
    const errBox = this.els.lockLayer.querySelector('#unlockError');

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      errBox.classList.add('hidden');
      const fd = new FormData(form);
      try {
        const res = await api.post('/api/auth.php?action=unlock', {
          password: fd.get('password'),
          totp_code: fd.get('totp_code') || '',
        }, { silentLock: true });

        this.state.locked = false;
        this.state.user = res.user;
        this.els.lockLayer.classList.add('hidden');
        this.els.lockLayer.innerHTML = '';
        this.fetchPulse();
      } catch (err) {
        errBox.textContent = err.message;
        errBox.classList.remove('hidden');
      }
    });

    this.els.lockLayer.querySelector('#switchUserBtn').addEventListener('click', async () => {
      await api.post('/api/auth.php?action=logout', {}, { silentLock: true });
      this.els.lockLayer.classList.add('hidden');
      this.stopPulse();
      this.state.authenticated = false;
      this.renderLoginScreen();
    });
  }

  // ==========================================================================
  // 4. ENTRÉE SUR LE BUREAU HYBRIDE & LANCEUR PWA
  // ==========================================================================

  hideDesktopChrome() {
    this.els.topbar.classList.add('hidden');
    this.els.desktop.classList.add('hidden');
    this.els.dockWrap.classList.add('hidden');
    this.els.mobileTaskbar.classList.add('hidden');
  }

  async enterDesktop() {
    this.els.authLayer.classList.add('hidden');
    this.els.authLayer.innerHTML = '';

    this.applyUserPreferences(this.state.user);

    this.els.topbar.classList.remove('hidden');
    this.els.desktop.classList.remove('hidden');
    this.els.dockWrap.classList.remove('hidden');
    this.els.mobileTaskbar.classList.remove('hidden');

    await this.loadShortcuts();
    this.startPulse();

    // Support des raccourcis PWA (?launch=docker-manager)
    const params = new URLSearchParams(window.location.search);
    const launchId = params.get('launch');
    if (launchId) {
      this.launchAppById(launchId);
      window.history.replaceState({}, '', '/');
    }
  }

  applyUserPreferences(user) {
    if (!user) return;
    this.state.user = user;
    const theme = user.theme_mode === 'light' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', theme);
    document.documentElement.setAttribute('data-wallpaper', user.wallpaper || 'aurora-coral');
    if (user.accent_color) {
      document.documentElement.style.setProperty('--os-accent', user.accent_color);
    }
  }

  async loadShortcuts() {
    const data = await api.get('/api/system.php?action=shortcuts');
    this.state.shortcuts = data.shortcuts || [];
    this.renderDesktopIcons();
    this.renderDock();
  }

  renderDesktopIcons() {
    const desktopApps = this.state.shortcuts.filter((s) => s.pinned_desktop);
    this.els.iconsGrid.innerHTML = desktopApps.map((app) => `
      <button type="button" class="desktop-icon-item" data-app-id="${app.app_id}">
        <span class="app-squircle" style="background:${app.accent_color}">${getAppIconSvg(app.icon)}</span>
        <span class="desktop-icon-label">${this.escapeHtml(app.title)}</span>
      </button>
    `).join('');

    this.els.iconsGrid.querySelectorAll('.desktop-icon-item').forEach((btn) => {
      btn.addEventListener('click', () => this.launchAppById(btn.dataset.appId));
    });
  }

  renderDock() {
    const pinned = this.state.shortcuts.filter((s) => s.pinned_dock);
    const openWins = Array.from(this.wm.windows.values());
    const pinnedIds = new Set(pinned.map((s) => s.app_id));

    // Applications ouvertes mais non épinglées dans le dock
    const transient = openWins
      .filter((w) => !pinnedIds.has(w.appId))
      .map((w) => this.state.shortcuts.find((s) => s.app_id === w.appId) || {
        app_id: w.appId,
        title: w.title,
        icon: w.icon,
        accent_color: w.accentColor,
      });

    const renderBtn = (app) => {
      const win = this.wm.findByAppId(app.app_id);
      const isRunning = Boolean(win);
      const isFocused = Boolean(win && !win.minimized && this.wm.focusedId === win.id);
      return `
        <button type="button" class="dock-item ${isRunning ? 'is-running' : ''} ${isFocused ? 'is-focused' : ''}" data-dock-app="${app.app_id}">
          <span class="dock-tooltip">${this.escapeHtml(app.title)}</span>
          <span class="app-squircle" style="background:${app.accent_color}">${getAppIconSvg(app.icon)}</span>
          <span class="dock-dot"></span>
        </button>
      `;
    };

    let html = pinned.map(renderBtn).join('');
    if (transient.length > 0) {
      html += `<div class="dock-divider"></div>` + transient.map(renderBtn).join('');
    }
    this.els.dock.innerHTML = html;

    this.els.dock.querySelectorAll('[data-dock-app]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const app = this.state.shortcuts.find((s) => s.app_id === btn.dataset.dockApp);
        if (app) this.wm.toggleFromDock(app);
      });
    });
  }

  onWindowsStateChanged({ activeWindow }) {
    this.els.activeAppTitle.textContent = activeWindow ? activeWindow.title : 'Bureau';
    this.renderDock();
  }

  launchAppById(appId, launchParams = {}) {
    const app = this.state.shortcuts.find((s) => s.app_id === appId);
    if (app) {
      this.wm.open(app, launchParams);
    }
  }

  // ==========================================================================
  // 5. TÉLÉMÉTRIE TEMPS RÉEL (CPU / RAM / NOTIFICATIONS / HORLOGE)
  // ==========================================================================

  startClock() {
    const tick = () => {
      const now = new Date();
      const str = now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
      const day = now.toLocaleDateString('fr-FR', { weekday: 'short', day: 'numeric', month: 'short' });
      if (this.els.clockText) {
        this.els.clockText.textContent = `${day}  ${str}`;
      }
      const lockDigits = document.getElementById('lockClockDigits');
      if (lockDigits) {
        lockDigits.textContent = str;
      }
    };
    tick();
    this.state.clockTimer = setInterval(tick, 10000);
  }

  startPulse() {
    this.stopPulse();
    this.fetchPulse();
    const interval = Math.max(2000, Number(this.state.os.metrics_interval) || 3000);
    this.state.pulseTimer = setInterval(() => {
      if (!this.state.locked && !document.hidden) {
        this.fetchPulse();
      }
    }, interval);
  }

  stopPulse() {
    if (this.state.pulseTimer) {
      clearInterval(this.state.pulseTimer);
      this.state.pulseTimer = null;
    }
  }

  async fetchPulse() {
    try {
      const data = await api.get('/api/system.php?action=pulse');
      const cpu = Number(data.metrics?.cpu?.total_percent || 0);
      const ram = Number(data.metrics?.memory?.used_percent || 0);

      this.els.cpuText.textContent = `${cpu.toFixed(0)}%`;
      this.els.cpuBar.style.width = `${Math.min(100, cpu)}%`;
      this.els.cpuBar.style.backgroundColor = cpu > 85 ? 'var(--os-danger)' : cpu > 65 ? 'var(--os-warning)' : 'var(--os-success)';

      this.els.ramText.textContent = `${ram.toFixed(0)}%`;
      this.els.ramBar.style.width = `${Math.min(100, ram)}%`;
      this.els.ramBar.style.backgroundColor = ram > 85 ? 'var(--os-danger)' : ram > 70 ? 'var(--os-warning)' : 'var(--os-info)';

      // Mise à jour carte mobile iPadOS / umbrelOS
      if (this.els.mobileHero) {
        this.els.mobileHero.innerHTML = `
          <div>
            <div style="font-size:0.74rem;color:var(--os-text-secondary);">Serveur Debian</div>
            <div style="font-weight:700;font-size:0.98rem;">${this.escapeHtml(data.hostname || 'debian')}</div>
          </div>
          <div style="text-align:right;font-family:var(--font-mono);font-size:0.8rem;">
            <div>CPU <strong style="color:var(--os-success)">${cpu.toFixed(0)}%</strong></div>
            <div>RAM <strong style="color:var(--os-info)">${ram.toFixed(0)}%</strong></div>
          </div>
        `;
      }

      const unread = Number(data.unread_notifications || 0);
      if (unread > 0) {
        this.els.notifBadge.textContent = String(unread);
        this.els.notifBadge.classList.remove('hidden');
      } else {
        this.els.notifBadge.classList.add('hidden');
      }
    } catch (_) {
      // Silencieux en cas de micro-coupure
    }
  }

  // ==========================================================================
  // 6. SPOTLIGHT (CTRL+K), NOTIFICATIONS & MENU CONTEXTUEL
  // ==========================================================================

  toggleSpotlight() {
    const isHidden = this.els.spotlightBackdrop.classList.contains('hidden');
    this.closeFloatingPanels();
    if (isHidden) {
      this.els.spotlightBackdrop.classList.remove('hidden');
      this.els.spotlightInput.value = '';
      this.renderSpotlightItems('');
      setTimeout(() => this.els.spotlightInput.focus(), 20);
    }
  }

  renderSpotlightItems(query) {
    const q = query.trim().toLowerCase();
    const matches = this.state.shortcuts.filter(
      (s) => q === '' || s.title.toLowerCase().includes(q) || (s.subtitle || '').toLowerCase().includes(q)
    );

    this.els.spotlightResults.innerHTML = matches.map((app, i) => `
      <button type="button" class="spotlight-item ${i === 0 ? 'is-selected' : ''}" data-spot-app="${app.app_id}">
        <div style="display:flex;align-items:center;gap:12px;">
          <span class="win-app-badge" style="width:32px;height:32px;border-radius:9px;background:${app.accent_color}">
            ${getAppIconSvg(app.icon)}
          </span>
          <div>
            <div style="font-weight:600;font-size:0.88rem;">${this.escapeHtml(app.title)}</div>
            <div style="font-size:0.76rem;color:var(--os-text-secondary);">${this.escapeHtml(app.subtitle || '')}</div>
          </div>
        </div>
        <span style="font-size:0.74rem;color:var(--os-text-muted);">Ouvrir ↵</span>
      </button>
    `).join('') || `<div style="padding:18px;text-align:center;color:var(--os-text-secondary);">Aucun module correspondant.</div>`;

    this.els.spotlightResults.querySelectorAll('[data-spot-app]').forEach((btn) => {
      btn.addEventListener('click', () => {
        this.els.spotlightBackdrop.classList.add('hidden');
        this.launchAppById(btn.dataset.spotApp);
      });
    });
  }

  async toggleNotificationsDrawer() {
    const willOpen = this.els.notifDrawer.classList.contains('hidden');
    this.closeFloatingPanels();
    if (willOpen) {
      this.els.notifDrawer.classList.remove('hidden');
      await this.loadNotifications();
    }
  }

  async loadNotifications() {
    const res = await api.get('/api/system.php?action=notifications');
    const items = res.notifications || [];
    if (items.length === 0) {
      this.els.notifList.innerHTML = `<div style="padding:24px;text-align:center;color:var(--os-text-secondary);font-size:0.84rem;">Aucune notification système.</div>`;
      return;
    }

    this.els.notifList.innerHTML = items.map((n) => `
      <div class="notif-card" data-notif-payload="${this.escapeHtml(n.action_payload_json || '')}" style="cursor:${n.action_payload_json ? 'pointer' : 'default'};border-left:3px solid ${n.level === 'error' ? 'var(--os-danger)' : n.level === 'success' ? 'var(--os-success)' : 'var(--os-accent)'}">
        <div style="font-weight:600;font-size:0.84rem;margin-bottom:3px;">${this.escapeHtml(n.title)}</div>
        <div style="font-size:0.79rem;color:var(--os-text-secondary);margin-bottom:6px;">${this.escapeHtml(n.message)}</div>
        <div style="font-size:0.7rem;color:var(--os-text-muted);font-family:var(--font-mono);">${this.escapeHtml(n.created_at)}</div>
      </div>
    `).join('');

    this.els.notifList.querySelectorAll('[data-notif-payload]').forEach((card) => {
      if (!card.dataset.notifPayload) return;
      card.addEventListener('click', () => {
        try {
          const payload = JSON.parse(card.dataset.notifPayload);
          if (payload.app) {
            this.els.notifDrawer.classList.add('hidden');
            this.launchAppById(payload.app, payload);
          }
        } catch (_) {}
      });
    });
  }

  openContextMenu(x, y, appId) {
    const app = appId ? this.state.shortcuts.find((s) => s.app_id === appId) : null;
    let html = '';

    if (app) {
      html = `
        <button type="button" class="ctx-item" data-ctx="open">Ouvrir ${this.escapeHtml(app.title)}</button>
        <button type="button" class="ctx-item" data-ctx="toggle-dock">${app.pinned_dock ? 'Retirer du Dock' : 'Épingler dans le Dock'}</button>
        <div class="ctx-sep"></div>
      `;
    }

    html += `
      <button type="button" class="ctx-item" data-ctx="spotlight">Recherche rapide (Ctrl+K)</button>
      <button type="button" class="ctx-item" data-ctx="appearance">Apparence, 2FA & Réseau</button>
      <button type="button" class="ctx-item" data-ctx="refresh">Actualiser le bureau</button>
      <div class="ctx-sep"></div>
      <button type="button" class="ctx-item" data-ctx="lock">Verrouiller l'écran (DSM)</button>
    `;

    this.els.contextMenu.innerHTML = html;
    this.els.contextMenu.classList.remove('hidden');

    const menuW = 225;
    const menuH = this.els.contextMenu.offsetHeight || 200;
    this.els.contextMenu.style.left = `${Math.min(x, window.innerWidth - menuW - 8)}px`;
    this.els.contextMenu.style.top = `${Math.min(y, window.innerHeight - menuH - 8)}px`;

    this.els.contextMenu.querySelectorAll('[data-ctx]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        this.els.contextMenu.classList.add('hidden');
        const act = btn.dataset.ctx;
        if (act === 'open' && app) {
          this.launchAppById(app.app_id);
        } else if (act === 'toggle-dock' && app) {
          await api.post('/api/system.php?action=shortcut_toggle_dock', {
            app_id: app.app_id,
            pinned_dock: !app.pinned_dock,
          });
          await this.loadShortcuts();
        } else if (act === 'spotlight') {
          this.toggleSpotlight();
        } else if (act === 'appearance') {
          this.launchAppById('system-settings');
        } else if (act === 'refresh') {
          await this.loadShortcuts();
          await this.fetchPulse();
        } else if (act === 'lock') {
          await api.post('/api/auth.php?action=lock');
          this.state.locked = true;
          this.showLockScreen();
        }
      });
    });
  }

  toast(message, type = 'info') {
    const el = document.createElement('div');
    el.className = 'os-toast';
    el.style.borderLeft = `4px solid ${type === 'error' ? 'var(--os-danger)' : 'var(--os-accent)'}`;
    el.textContent = message;
    this.els.toastStack.appendChild(el);
    setTimeout(() => el.remove(), 4200);
  }

  escapeHtml(str) {
    return String(str ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const desktop = new VanillIADesktop();
  window.__VANILLIA_DESKTOP__ = desktop;
  desktop.init();
});
