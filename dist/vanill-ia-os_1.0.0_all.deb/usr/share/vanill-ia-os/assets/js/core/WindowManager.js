/**
 * ==============================================================================
 * Vanill-IA OS — Multi-Window Engine (WindowManager.js)
 * - Smooth Pointer Drag & Drop with Edge Snap Preview (Left / Right / Maximize)
 * - 8-Direction Resizing + Iframe Pointer Shield for Embedded Docker Apps
 * - Minimize to Dock, Restore, Maximize, Z-Index Focus Stack, Mobile Fullscreen
 * - Dynamic Module Loader (/assets/js/apps/<appId>.js) + Built-in Security Panel
 * ==============================================================================
 */

import { api } from './ApiClient.js';
import { renderQrCodeSvg } from './QrCode.js';

export const Icons = {
  layers: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>',
  activity: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>',
  'folder-open': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>',
  sparkles: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3Z"/><path d="M5 3v4"/><path d="M3 5h4"/></svg>',
  terminal: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><polyline points="4 17 10 11 4 5"/><line x1="12" y1="19" x2="20" y2="19"/></svg>',
  clock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
  sliders: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="2" y1="14" x2="6" y2="14"/><line x1="10" y1="8" x2="14" y2="8"/><line x1="18" y1="16" x2="22" y2="16"/></svg>',
  'file-code': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><polyline points="10 13 8 15 10 17"/><polyline points="14 13 16 15 14 17"/></svg>',
  'book-open': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>',
  globe: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>',
  box: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>',
  minimize: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round"><line x1="5" y1="12" x2="19" y2="12"/></svg>',
  maximize: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="4" width="16" height="16" rx="2.5"/></svg>',
  close: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
  external: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>',
  refresh: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>',
};

export function getAppIconSvg(name) {
  return Icons[name] || Icons.box;
}

export class WindowManager {
  constructor({ containerEl, snapPreviewEl, onStateChange }) {
    this.containerEl = containerEl;
    this.snapPreviewEl = snapPreviewEl;
    this.onStateChange = onStateChange || (() => {});
    this.windows = new Map(); // winId -> windowRecord
    this.zCounter = 100;
    this.focusedId = null;

    window.addEventListener('keydown', (e) => {
      if (e.altKey && e.key.toLowerCase() === 'w' && this.focusedId) {
        e.preventDefault();
        this.close(this.focusedId);
      }
    });
  }

  isMobileViewport() {
    return window.matchMedia('(max-width: 860px)').matches;
  }

  getWorkspaceBounds() {
    const rect = this.containerEl.getBoundingClientRect();
    const dockReserve = this.isMobileViewport() ? 0 : 78;
    return {
      width: rect.width,
      height: Math.max(280, rect.height - dockReserve),
      fullHeight: rect.height,
    };
  }

  findByAppId(appId) {
    for (const win of this.windows.values()) {
      if (win.appId === appId) return win;
    }
    return null;
  }

  async open(appDef, launchParams = {}) {
    if (appDef.open_mode === 'tab' && appDef.target_url) {
      window.open(appDef.target_url, '_blank', 'noopener,noreferrer');
      return null;
    }

    const existing = this.findByAppId(appDef.app_id);
    if (existing) {
      if (existing.minimized) {
        this.restore(existing.id);
      } else {
        this.focus(existing.id);
      }
      if (typeof existing.instanceOnLaunch === 'function' && Object.keys(launchParams).length > 0) {
        existing.instanceOnLaunch(launchParams);
      }
      return existing;
    }

    const winId = `win-${appDef.app_id}-${Date.now().toString(36)}`;
    const bounds = this.getWorkspaceBounds();
    const count = this.windows.size;
    const width = Math.min(appDef.defaultWidth || 920, Math.max(360, bounds.width - 36));
    const height = Math.min(appDef.defaultHeight || 600, Math.max(300, bounds.height - 24));
    const cascade = (count % 6) * 26;
    const left = Math.max(12, Math.round((bounds.width - width) / 2) + cascade - 40);
    const top = Math.max(10, Math.round((bounds.height - height) / 2) + cascade - 30);

    const el = document.createElement('section');
    el.className = 'os-window';
    el.dataset.winId = winId;
    el.style.left = `${left}px`;
    el.style.top = `${top}px`;
    el.style.width = `${width}px`;
    el.style.height = `${height}px`;

    const accent = appDef.accent_color || '#FF6D5A';
    el.innerHTML = `
      <header class="win-header">
        <div class="win-title-group">
          <span class="win-app-badge" style="background:${accent}">${getAppIconSvg(appDef.icon)}</span>
          <span class="win-title"></span>
        </div>
        <div class="win-controls">
          <button type="button" class="win-ctrl-btn minimize" title="Réduire dans le Dock">${Icons.minimize}</button>
          <button type="button" class="win-ctrl-btn maximize" title="Agrandir / Restaurer">${Icons.maximize}</button>
          <button type="button" class="win-ctrl-btn close" title="Fermer (Alt+W)">${Icons.close}</button>
        </div>
      </header>
      <div class="win-body"></div>
      <div class="win-resize win-resize-n" data-dir="n"></div>
      <div class="win-resize win-resize-s" data-dir="s"></div>
      <div class="win-resize win-resize-e" data-dir="e"></div>
      <div class="win-resize win-resize-w" data-dir="w"></div>
      <div class="win-resize win-resize-ne" data-dir="ne"></div>
      <div class="win-resize win-resize-nw" data-dir="nw"></div>
      <div class="win-resize win-resize-se" data-dir="se"></div>
      <div class="win-resize win-resize-sw" data-dir="sw"></div>
    `;

    el.querySelector('.win-title').textContent = appDef.title || appDef.app_id;

    const record = {
      id: winId,
      appId: appDef.app_id,
      title: appDef.title || appDef.app_id,
      icon: appDef.icon || 'box',
      accentColor: accent,
      el,
      bodyEl: el.querySelector('.win-body'),
      minimized: false,
      maximized: false,
      savedRect: { left, top, width, height },
      cleanup: null,
      instanceOnLaunch: null,
    };

    this.bindWindowEvents(record);
    this.containerEl.appendChild(el);
    this.windows.set(winId, record);
    this.focus(winId);

    await this.mountWindowContent(record, appDef, launchParams);
    this.emitChange();
    return record;
  }

  bindWindowEvents(record) {
    const { el, id } = record;
    const header = el.querySelector('.win-header');
    const btnMin = el.querySelector('.win-ctrl-btn.minimize');
    const btnMax = el.querySelector('.win-ctrl-btn.maximize');
    const btnClose = el.querySelector('.win-ctrl-btn.close');

    el.addEventListener('pointerdown', () => this.focus(id));
    btnMin.addEventListener('click', (e) => {
      e.stopPropagation();
      this.minimize(id);
    });
    btnMax.addEventListener('click', (e) => {
      e.stopPropagation();
      this.toggleMaximize(id);
    });
    btnClose.addEventListener('click', (e) => {
      e.stopPropagation();
      this.close(id);
    });
    header.addEventListener('dblclick', (e) => {
      if (!e.target.closest('.win-controls') && !this.isMobileViewport()) {
        this.toggleMaximize(id);
      }
    });

    // Drag & Drop fluide + Aero Snap
    header.addEventListener('pointerdown', (e) => {
      if (e.button !== 0 || e.target.closest('.win-controls') || this.isMobileViewport()) {
        return;
      }
      this.focus(id);

      let startX = e.clientX;
      let startY = e.clientY;

      if (record.maximized) {
        const ratio = e.clientX / window.innerWidth;
        record.maximized = false;
        el.classList.remove('is-maximized');
        const w = record.savedRect.width;
        const h = record.savedRect.height;
        const restoredLeft = Math.max(8, Math.round(e.clientX - w * ratio));
        el.style.width = `${w}px`;
        el.style.height = `${h}px`;
        el.style.left = `${restoredLeft}px`;
        el.style.top = '8px';
      }

      const initLeft = parseFloat(el.style.left) || 0;
      const initTop = parseFloat(el.style.top) || 0;
      let pendingSnap = null;

      el.classList.add('is-interacting');
      document.body.classList.add('is-dragging-window');
      header.setPointerCapture(e.pointerId);

      const onMove = (ev) => {
        const dx = ev.clientX - startX;
        const dy = ev.clientY - startY;
        const bounds = this.getWorkspaceBounds();
        const nextLeft = Math.max(-record.el.offsetWidth + 120, Math.min(bounds.width - 120, initLeft + dx));
        const nextTop = Math.max(0, Math.min(bounds.fullHeight - 44, initTop + dy));

        el.style.left = `${nextLeft}px`;
        el.style.top = `${nextTop}px`;

        // Détection des zones magnétiques (gauche / droite / haut)
        if (ev.clientX <= 14) {
          pendingSnap = 'left';
          this.showSnapPreview('left');
        } else if (ev.clientX >= window.innerWidth - 14) {
          pendingSnap = 'right';
          this.showSnapPreview('right');
        } else if (ev.clientY <= 44) {
          pendingSnap = 'maximize';
          this.showSnapPreview('maximize');
        } else {
          pendingSnap = null;
          this.hideSnapPreview();
        }
      };

      const onUp = (ev) => {
        header.removeEventListener('pointermove', onMove);
        header.removeEventListener('pointerup', onUp);
        header.removeEventListener('pointercancel', onUp);
        el.classList.remove('is-interacting');
        document.body.classList.remove('is-dragging-window');
        this.hideSnapPreview();

        if (pendingSnap === 'maximize') {
          this.toggleMaximize(id, true);
        } else if (pendingSnap === 'left' || pendingSnap === 'right') {
          this.snapSide(id, pendingSnap);
        } else {
          record.savedRect = {
            left: parseFloat(el.style.left) || 0,
            top: parseFloat(el.style.top) || 0,
            width: el.offsetWidth,
            height: el.offsetHeight,
          };
        }
      };

      header.addEventListener('pointermove', onMove);
      header.addEventListener('pointerup', onUp);
      header.addEventListener('pointercancel', onUp);
    });

    // Redimensionnement 8 directions
    el.querySelectorAll('.win-resize').forEach((handle) => {
      handle.addEventListener('pointerdown', (e) => {
        if (e.button !== 0 || record.maximized || this.isMobileViewport()) return;
        e.stopPropagation();
        this.focus(id);

        const dir = handle.dataset.dir || 'se';
        const startX = e.clientX;
        const startY = e.clientY;
        const startRect = {
          left: parseFloat(el.style.left) || 0,
          top: parseFloat(el.style.top) || 0,
          width: el.offsetWidth,
          height: el.offsetHeight,
        };
        const minW = 360;
        const minH = 260;

        el.classList.add('is-interacting');
        document.body.classList.add('is-dragging-window');
        handle.setPointerCapture(e.pointerId);

        const onMove = (ev) => {
          const dx = ev.clientX - startX;
          const dy = ev.clientY - startY;
          let { left, top, width, height } = startRect;

          if (dir.includes('e')) width = Math.max(minW, startRect.width + dx);
          if (dir.includes('s')) height = Math.max(minH, startRect.height + dy);
          if (dir.includes('w')) {
            const candidateW = startRect.width - dx;
            if (candidateW >= minW) {
              width = candidateW;
              left = startRect.left + dx;
            }
          }
          if (dir.includes('n')) {
            const candidateH = startRect.height - dy;
            if (candidateH >= minH && startRect.top + dy >= 0) {
              height = candidateH;
              top = startRect.top + dy;
            }
          }

          el.style.left = `${left}px`;
          el.style.top = `${top}px`;
          el.style.width = `${width}px`;
          el.style.height = `${height}px`;
        };

        const onUp = () => {
          handle.removeEventListener('pointermove', onMove);
          handle.removeEventListener('pointerup', onUp);
          handle.removeEventListener('pointercancel', onUp);
          el.classList.remove('is-interacting');
          document.body.classList.remove('is-dragging-window');
          record.savedRect = {
            left: parseFloat(el.style.left) || 0,
            top: parseFloat(el.style.top) || 0,
            width: el.offsetWidth,
            height: el.offsetHeight,
          };
        };

        handle.addEventListener('pointermove', onMove);
        handle.addEventListener('pointerup', onUp);
        handle.addEventListener('pointercancel', onUp);
      });
    });
  }

  showSnapPreview(mode) {
    if (!this.snapPreviewEl) return;
    const topOffset = this.containerEl.getBoundingClientRect().top;
    const bounds = this.getWorkspaceBounds();

    this.snapPreviewEl.classList.remove('hidden');
    if (mode === 'left') {
      this.snapPreviewEl.style.top = `${topOffset + 8}px`;
      this.snapPreviewEl.style.left = '8px';
      this.snapPreviewEl.style.width = `${Math.round(bounds.width / 2) - 12}px`;
      this.snapPreviewEl.style.height = `${bounds.height - 16}px`;
    } else if (mode === 'right') {
      this.snapPreviewEl.style.top = `${topOffset + 8}px`;
      this.snapPreviewEl.style.left = `${Math.round(bounds.width / 2) + 4}px`;
      this.snapPreviewEl.style.width = `${Math.round(bounds.width / 2) - 12}px`;
      this.snapPreviewEl.style.height = `${bounds.height - 16}px`;
    } else {
      this.snapPreviewEl.style.top = `${topOffset + 6}px`;
      this.snapPreviewEl.style.left = '6px';
      this.snapPreviewEl.style.width = `${bounds.width - 12}px`;
      this.snapPreviewEl.style.height = `${bounds.height - 12}px`;
    }
  }

  hideSnapPreview() {
    if (this.snapPreviewEl) {
      this.snapPreviewEl.classList.add('hidden');
    }
  }

  snapSide(winId, side) {
    const record = this.windows.get(winId);
    if (!record) return;
    const bounds = this.getWorkspaceBounds();
    const halfW = Math.round(bounds.width / 2) - 8;

    record.maximized = false;
    record.el.classList.remove('is-maximized');
    record.el.style.top = '6px';
    record.el.style.left = side === 'left' ? '6px' : `${Math.round(bounds.width / 2) + 2}px`;
    record.el.style.width = `${halfW}px`;
    record.el.style.height = `${bounds.height - 12}px`;
  }

  focus(winId) {
    const record = this.windows.get(winId);
    if (!record) return;

    this.zCounter += 1;
    record.el.style.zIndex = String(this.zCounter);
    this.focusedId = winId;

    for (const [id, win] of this.windows.entries()) {
      win.el.classList.toggle('is-focused', id === winId && !win.minimized);
    }
    this.emitChange();
  }

  minimize(winId) {
    const record = this.windows.get(winId);
    if (!record) return;
    record.minimized = true;
    record.el.classList.add('is-minimized');
    record.el.classList.remove('is-focused');

    if (this.focusedId === winId) {
      this.focusedId = null;
      // Focus sur la fenêtre visible la plus haute
      let best = null;
      for (const win of this.windows.values()) {
        if (!win.minimized && (!best || Number(win.el.style.zIndex) > Number(best.el.style.zIndex))) {
          best = win;
        }
      }
      if (best) this.focus(best.id);
    }
    this.emitChange();
  }

  restore(winId) {
    const record = this.windows.get(winId);
    if (!record) return;
    record.minimized = false;
    record.el.classList.remove('is-minimized');
    this.focus(winId);
  }

  toggleFromDock(appDef) {
    const existing = this.findByAppId(appDef.app_id);
    if (!existing) {
      this.open(appDef);
      return;
    }
    if (existing.minimized) {
      this.restore(existing.id);
    } else if (this.focusedId === existing.id) {
      this.minimize(existing.id);
    } else {
      this.focus(existing.id);
    }
  }

  toggleMaximize(winId, forceMax = null) {
    const record = this.windows.get(winId);
    if (!record) return;
    const shouldMax = forceMax !== null ? forceMax : !record.maximized;

    if (shouldMax) {
      if (!record.maximized) {
        record.savedRect = {
          left: parseFloat(record.el.style.left) || 0,
          top: parseFloat(record.el.style.top) || 0,
          width: record.el.offsetWidth,
          height: record.el.offsetHeight,
        };
      }
      const bounds = this.getWorkspaceBounds();
      record.maximized = true;
      record.el.classList.add('is-maximized');
      record.el.style.left = '0px';
      record.el.style.top = '0px';
      record.el.style.width = `${bounds.width}px`;
      record.el.style.height = `${bounds.height}px`;
    } else {
      record.maximized = false;
      record.el.classList.remove('is-maximized');
      record.el.style.left = `${record.savedRect.left}px`;
      record.el.style.top = `${record.savedRect.top}px`;
      record.el.style.width = `${record.savedRect.width}px`;
      record.el.style.height = `${record.savedRect.height}px`;
    }
  }

  close(winId) {
    const record = this.windows.get(winId);
    if (!record) return;
    if (typeof record.cleanup === 'function') {
      try { record.cleanup(); } catch (_) {}
    }
    record.el.remove();
    this.windows.delete(winId);

    if (this.focusedId === winId) {
      this.focusedId = null;
      let best = null;
      for (const win of this.windows.values()) {
        if (!win.minimized && (!best || Number(win.el.style.zIndex) > Number(best.el.style.zIndex))) {
          best = win;
        }
      }
      if (best) this.focus(best.id);
    }
    this.emitChange();
  }

  minimizeAll() {
    for (const win of this.windows.values()) {
      win.minimized = true;
      win.el.classList.add('is-minimized');
      win.el.classList.remove('is-focused');
    }
    this.focusedId = null;
    this.emitChange();
  }

  emitChange() {
    const active = this.focusedId ? this.windows.get(this.focusedId) : null;
    this.onStateChange({
      activeWindow: active || null,
      windows: Array.from(this.windows.values()),
    });
  }

  /**
   * Charge dynamiquement l'application (iframe Web/Docker, module ES6 dédié ou panneau intégré).
   */
  async mountWindowContent(record, appDef, launchParams) {
    const { bodyEl } = record;

    // 1. Fenêtre Iframe (Conteneur Docker exposé ou WebApp interne)
    if (appDef.open_mode === 'iframe' && appDef.target_url) {
      bodyEl.innerHTML = `
        <div class="win-iframe-bar">
          <span style="font-family:var(--font-mono);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"></span>
          <div style="display:flex;gap:8px;flex-shrink:0;">
            <button type="button" class="os-btn os-btn-ghost" data-act="reload" style="padding:4px 9px;font-size:0.74rem;">${Icons.refresh} Actualiser</button>
            <button type="button" class="os-btn os-btn-ghost" data-act="ext" style="padding:4px 9px;font-size:0.74rem;">${Icons.external} Nouvel onglet</button>
          </div>
        </div>
        <iframe class="win-iframe" referrerpolicy="no-referrer" allow="clipboard-read; clipboard-write; fullscreen"></iframe>
      `;
      bodyEl.querySelector('.win-iframe-bar span').textContent = appDef.target_url;
      const iframe = bodyEl.querySelector('iframe');
      iframe.src = appDef.target_url;

      bodyEl.querySelector('[data-act="reload"]').addEventListener('click', () => {
        iframe.src = appDef.target_url;
      });
      bodyEl.querySelector('[data-act="ext"]').addEventListener('click', () => {
        window.open(appDef.target_url, '_blank', 'noopener,noreferrer');
      });
      return;
    }

    // 2. Tentative de chargement du contrôleur JS dédié (/assets/js/apps/<appId>.js — Étapes 3 à 6)
    try {
      const mod = await import(`../apps/${appDef.app_id}.js`);
      if (mod && typeof mod.mountApp === 'function') {
        const handle = await mod.mountApp({
          container: bodyEl,
          app: appDef,
          params: launchParams,
          api,
          windowRecord: record,
        });
        if (handle && typeof handle.cleanup === 'function') {
          record.cleanup = handle.cleanup;
        }
        if (handle && typeof handle.onLaunch === 'function') {
          record.instanceOnLaunch = handle.onLaunch;
        }
        return;
      }
    } catch (_) {
      // Module applicatif prévu dans les Étapes 3..6 ou vue socle Étape 2
    }

    // 3. Vue native Sécurité, 2FA, Isolation Réseau & Apparence intégrée dès l'Étape 2
    if (appDef.app_id === 'system-settings') {
      this.renderSecurityAndAppearancePane(bodyEl);
      return;
    }

    // 4. Placeholder propre et informatif pour les modules des Étapes 3 à 6
    const stepMap = {
      'docker-manager': 'Étape 3 — Moteur Docker, Stacks Compose, App Store & Reverse Proxy Caddy',
      'resource-monitor': 'Étape 4 — Moniteur de Ressources Temps Réel, Capteurs & Santé SMART',
      'cron-manager': 'Étape 4 — Planificateur de Tâches Cron Visuel & Journaux SQLite',
      'file-station': 'Étape 5 — Explorateur File Station, Archives Zip & Prévisualisation',
      'code-editor': 'Étape 5 — Éditeur CodeMirror Intégré (Configs, Scripts & YAML)',
      'notes': 'Étape 5 — Bloc-notes Markdown (.md)',
      'terminal': 'Étape 5 — Terminal Web Interactif (xterm.js / Shell Debian)',
      'vanill-ia-chat': 'Étape 6 — Client Chat Vanill-IA (Ollama + BYOK Gemini 3.8 Flash) & Diagnostic Logs',
    };

    bodyEl.innerHTML = `
      <div class="app-pane">
        <div class="settings-card">
          <h3>${appDef.title}</h3>
          <p class="desc">${appDef.subtitle || ''}</p>
          <div class="os-alert os-alert-info" style="margin-bottom:0;">
            Ce module système est raccordé au moteur de fenêtres et prêt pour l'implémentation de son interface complète en <strong>${stepMap[appDef.app_id] || 'prochaine étape'}</strong>.
            Le backend privilégié (<code>vanill-ia-agent</code>) est déjà opérationnel.
          </div>
        </div>
      </div>
    `;
  }

  /**
   * Panneau fonctionnel dès l'Étape 2 : Apparence (Dark/Light + 5 Wallpapers),
   * Verrouillage auto DSM, 2FA TOTP (QR Code local) et Isolation Réseau LAN/Tailscale.
   */
  renderSecurityAndAppearancePane(container) {
    const state = window.__VANILLIA_DESKTOP__?.state || {};
    const user = state.user || {};
    const os = state.os || {};

    const wallpapers = [
      { id: 'aurora-coral', label: 'Aurora Coral', bg: 'linear-gradient(135deg, #FF6D5A 0%, #1E293B 60%, #0EA5E9 100%)' },
      { id: 'midnight-slate', label: 'Midnight Slate', bg: 'linear-gradient(135deg, #0F172A 0%, #2563EB 100%)' },
      { id: 'umbrel-twilight', label: 'Umbrel Twilight', bg: 'linear-gradient(135deg, #7C3AED 0%, #EC4899 100%)' },
      { id: 'emerald-abyss', label: 'Emerald Abyss', bg: 'linear-gradient(135deg, #064E3B 0%, #14B8A6 100%)' },
      { id: 'solar-sand', label: 'Solar Sand', bg: 'linear-gradient(135deg, #F59E0B 0%, #FF6D5A 100%)' },
    ];

    container.innerHTML = `
      <div class="app-pane">
        <div class="settings-card">
          <h3>Apparence & Bureau Hybride (DSM × umbrelOS)</h3>
          <p class="desc">Personnalisez le thème visuel, le fond d'écran et le délai de verrouillage automatique de session.</p>

          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px;margin-bottom:16px;">
            <div>
              <label class="form-label">Mode d'affichage</label>
              <select class="os-select" data-pref="theme_mode">
                <option value="dark" ${user.theme_mode === 'dark' ? 'selected' : ''}>Sombre (#0F1115 — Défaut)</option>
                <option value="light" ${user.theme_mode === 'light' ? 'selected' : ''}>Clair (Alabaster Glass)</option>
              </select>
            </div>
            <div>
              <label class="form-label">Verrouillage auto d'inactivité (DSM)</label>
              <select class="os-select" data-pref="session_lock_minutes">
                <option value="5" ${user.session_lock_minutes === 5 ? 'selected' : ''}>Après 5 minutes</option>
                <option value="15" ${user.session_lock_minutes === 15 ? 'selected' : ''}>Après 15 minutes</option>
                <option value="30" ${user.session_lock_minutes === 30 ? 'selected' : ''}>Après 30 minutes</option>
                <option value="60" ${user.session_lock_minutes === 60 ? 'selected' : ''}>Après 1 heure</option>
                <option value="0" ${user.session_lock_minutes === 0 ? 'selected' : ''}>Jamais</option>
              </select>
            </div>
          </div>

          <label class="form-label">Fond d'écran Mesh GPU</label>
          <div class="wallpaper-swatches">
            ${wallpapers.map((w) => `
              <button type="button" class="wp-swatch ${user.wallpaper === w.id ? 'active' : ''}" data-wp="${w.id}" style="background:${w.bg}">
                ${w.label}
              </button>
            `).join('')}
          </div>
        </div>

        <div class="settings-card">
          <h3>Double Authentification 2FA (TOTP RFC 6238)</h3>
          <p class="desc">Protégez l'accès administrateur avec Aegis, Bitwarden, Proton Authenticator ou Google Authenticator. Le QR Code est généré localement sans appel externe.</p>
          <div id="totpManageZone"></div>
        </div>

        <div class="settings-card">
          <h3>Isolation Réseau du WebOS (Caddy Guard)</h3>
          <p class="desc">Restreignez l'interface d'administration de Vanill-IA OS à votre réseau local ou VPN Tailscale tout en laissant vos conteneurs publics accessibles.</p>
          <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
            <select class="os-select" id="exposureModeSelect" style="max-width:340px;">
              <option value="all" ${os.network_exposure === 'all' ? 'selected' : ''}>Toutes les interfaces (WAN + LAN + Tailscale)</option>
              <option value="lan_tailscale" ${os.network_exposure === 'lan_tailscale' ? 'selected' : ''}>Réseau Local (RFC1918) + Tailscale uniquement</option>
              <option value="tailscale_only" ${os.network_exposure === 'tailscale_only' ? 'selected' : ''}>VPN Tailscale (100.64.0.0/10) exclusivement</option>
            </select>
            <button type="button" class="os-btn os-btn-primary" id="saveExposureBtn" style="width:auto;">Appliquer dans Caddy</button>
          </div>
        </div>
      </div>
    `;

    // Listeners Apparence
    container.querySelectorAll('[data-pref]').forEach((sel) => {
      sel.addEventListener('change', async () => {
        const theme_mode = container.querySelector('[data-pref="theme_mode"]').value;
        const session_lock_minutes = Number(container.querySelector('[data-pref="session_lock_minutes"]').value);
        try {
          const res = await api.post('/api/auth.php?action=preferences', { theme_mode, session_lock_minutes });
          window.__VANILLIA_DESKTOP__?.applyUserPreferences(res.user);
          window.__VANILLIA_DESKTOP__?.toast('Préférences enregistrées.');
        } catch (err) {
          window.__VANILLIA_DESKTOP__?.toast(err.message, 'error');
        }
      });
    });

    container.querySelectorAll('[data-wp]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const wallpaper = btn.dataset.wp;
        container.querySelectorAll('[data-wp]').forEach((b) => b.classList.toggle('active', b === btn));
        try {
          const res = await api.post('/api/auth.php?action=preferences', { wallpaper });
          window.__VANILLIA_DESKTOP__?.applyUserPreferences(res.user);
        } catch (err) {
          window.__VANILLIA_DESKTOP__?.toast(err.message, 'error');
        }
      });
    });

    // Listener Isolation Réseau Caddy
    container.querySelector('#saveExposureBtn').addEventListener('click', async () => {
      const mode = container.querySelector('#exposureModeSelect').value;
      try {
        await api.post('/api/system.php?action=network_exposure', { mode });
        if (window.__VANILLIA_DESKTOP__?.state?.os) {
          window.__VANILLIA_DESKTOP__.state.os.network_exposure = mode;
        }
        window.__VANILLIA_DESKTOP__?.toast('Politique réseau Caddy appliquée et rechargée.');
      } catch (err) {
        window.__VANILLIA_DESKTOP__?.toast(err.message, 'error');
      }
    });

    // Rendu de la section 2FA TOTP
    const totpZone = container.querySelector('#totpManageZone');
    const renderTotpState = () => {
      const enabled = Boolean(window.__VANILLIA_DESKTOP__?.state?.user?.totp_enabled);
      if (enabled) {
        totpZone.innerHTML = `
          <div class="os-alert os-alert-info">Le 2FA TOTP est actuellement <strong>ACTIF</strong> sur votre compte.</div>
          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;margin-bottom:10px;">
            <input type="password" class="os-input" id="disableTotpPass" placeholder="Mot de passe actuel">
            <input type="text" class="os-input code-totp" id="disableTotpCode" placeholder="Code 2FA" maxlength="9">
          </div>
          <button type="button" class="os-btn os-btn-ghost" id="disableTotpBtn" style="color:var(--os-danger);">Désactiver le 2FA</button>
        `;
        totpZone.querySelector('#disableTotpBtn').addEventListener('click', async () => {
          try {
            await api.post('/api/auth.php?action=totp_disable', {
              password: totpZone.querySelector('#disableTotpPass').value,
              totp_code: totpZone.querySelector('#disableTotpCode').value,
            });
            window.__VANILLIA_DESKTOP__.state.user.totp_enabled = false;
            window.__VANILLIA_DESKTOP__.toast('Double authentification 2FA désactivée.');
            renderTotpState();
          } catch (err) {
            window.__VANILLIA_DESKTOP__.toast(err.message, 'error');
          }
        });
      } else {
        totpZone.innerHTML = `<button type="button" class="os-btn os-btn-primary" id="startTotpBtn" style="width:auto;">Configurer le 2FA TOTP maintenant</button>`;
        totpZone.querySelector('#startTotpBtn').addEventListener('click', async () => {
          try {
            const prep = await api.post('/api/auth.php?action=totp_prepare');
            const svg = renderQrCodeSvg(prep.otpauth_uri);
            totpZone.innerHTML = `
              <div class="totp-setup-box">
                <div class="qr-frame">${svg}</div>
                <p style="text-align:center;font-family:var(--font-mono);font-size:0.78rem;margin-bottom:12px;" class="selectable">Clé manuelle : ${prep.secret}</p>
                <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;margin-bottom:10px;">
                  <input type="password" class="os-input" id="enableTotpPass" placeholder="Confirmez votre mot de passe">
                  <input type="text" class="os-input code-totp" id="enableTotpCode" placeholder="000000" maxlength="6" inputmode="numeric">
                </div>
                <button type="button" class="os-btn os-btn-primary" id="confirmTotpBtn">Valider et activer le 2FA</button>
              </div>
            `;
            totpZone.querySelector('#confirmTotpBtn').addEventListener('click', async () => {
              try {
                const res = await api.post('/api/auth.php?action=totp_enable', {
                  password: totpZone.querySelector('#enableTotpPass').value,
                  totp_code: totpZone.querySelector('#enableTotpCode').value,
                });
                window.__VANILLIA_DESKTOP__.state.user.totp_enabled = true;
                totpZone.innerHTML = `
                  <div class="os-alert os-alert-info"><strong>2FA activé !</strong> Conservez précieusement ces codes de secours à usage unique :</div>
                  <div class="backup-codes-grid selectable">
                    ${res.backup_codes.map((c) => `<div class="backup-code-chip">${c}</div>`).join('')}
                  </div>
                  <button type="button" class="os-btn os-btn-ghost" id="doneBackupBtn">J'ai sauvegardé mes codes</button>
                `;
                totpZone.querySelector('#doneBackupBtn').addEventListener('click', renderTotpState);
              } catch (err) {
                window.__VANILLIA_DESKTOP__.toast(err.message, 'error');
              }
            });
          } catch (err) {
            window.__VANILLIA_DESKTOP__.toast(err.message, 'error');
          }
        });
      }
    };

    renderTotpState();
  }
}
