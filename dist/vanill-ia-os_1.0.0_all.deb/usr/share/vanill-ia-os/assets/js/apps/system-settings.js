/**
 * ==============================================================================
 * Vanill-IA OS — Step 4: Debian Control Panel (Synology DSM Style)
 * 7 Unified Sections:
 *  1. Système & Alimentation
 *  2. Stockage (lsblk / mount /mnt/) & Partages Samba SMB
 *  3. Réseau, Tailscale & Isolation Caddy
 *  4. Pare-feu UFW & Prisons Fail2ban
 *  5. Services Systemd & Journalctl (+ Diagnostic IA)
 *  6. Mises à jour APT (apt update / apt upgrade)
 *  7. Sécurité 2FA TOTP, Apparence & Journal d'Audit
 * ==============================================================================
 */

import { renderQrCodeSvg } from '../core/QrCode.js';

function escapeHtml(str) {
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function formatBytes(bytes) {
  const n = Number(bytes) || 0;
  if (n <= 0) return '0 o';
  const units = ['o', 'Ko', 'Mo', 'Go', 'To'];
  const i = Math.min(units.length - 1, Math.floor(Math.log(n) / Math.log(1024)));
  return `${(n / (1024 ** i)).toFixed(i >= 3 ? 2 : 1)} ${units[i]}`;
}

export async function mountApp({ container, api, params }) {
  let activeSection = params?.section || 'overview';

  container.innerHTML = `
    <div class="module-layout">
      <aside class="module-sidebar">
        <button type="button" class="module-nav-btn active" data-sec="overview">🖥️ Système</button>
        <button type="button" class="module-nav-btn" data-sec="storage">💾 Stockage & SMB</button>
        <button type="button" class="module-nav-btn" data-sec="network">🌐 Réseau & VPN</button>
        <button type="button" class="module-nav-btn" data-sec="firewall">🛡️ UFW & Fail2ban</button>
        <button type="button" class="module-nav-btn" data-sec="services">⚙️ Services Systemd</button>
        <button type="button" class="module-nav-btn" data-sec="apt">📦 Mises à jour APT</button>
        <button type="button" class="module-nav-btn" data-sec="security">🔐 2FA & Apparence</button>
      </aside>
      <div class="module-content" id="sysSettingsPane"></div>
    </div>
    <div id="sysSettingsModal"></div>
  `;

  const pane = container.querySelector('#sysSettingsPane');
  const modalSlot = container.querySelector('#sysSettingsModal');
  const notify = (msg, type = 'info') => window.__VANILLIA_DESKTOP__?.toast(msg, type);

  const switchSection = async (sec) => {
    activeSection = sec;
    container.querySelectorAll('[data-sec]').forEach((b) => {
      b.classList.toggle('active', b.dataset.sec === sec);
    });
    pane.innerHTML = `<div class="settings-card">Chargement...</div>`;

    if (sec === 'overview') await renderOverview();
    else if (sec === 'storage') await renderStorage();
    else if (sec === 'network') await renderNetwork();
    else if (sec === 'firewall') await renderFirewall();
    else if (sec === 'services') await renderServices();
    else if (sec === 'apt') await renderApt();
    else if (sec === 'security') await renderSecurityAndAppearance();
  };

  container.querySelectorAll('[data-sec]').forEach((btn) => {
    btn.addEventListener('click', () => switchSection(btn.dataset.sec));
  });

  // ==========================================================================
  // 1. VUE D'ENSEMBLE SYSTÈME DEBIAN
  // ==========================================================================

  async function renderOverview() {
    try {
      const info = await api.get('/api/system.php?action=info');
      const d = Math.floor((info.uptime_sec || 0) / 86400);
      const h = Math.floor(((info.uptime_sec || 0) % 86400) / 3600);
      const m = Math.floor(((info.uptime_sec || 0) % 3600) / 60);

      pane.innerHTML = `
        <div class="settings-card">
          <h3>Informations Matérielles & Système Debian</h3>
          <p class="desc">Résumé technique du nœud administré par Vanill-IA OS.</p>

          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;">
            <div class="kpi-card">
              <div class="kpi-label">Nom d'hôte (Hostname)</div>
              <div class="kpi-value" style="font-size:1.1rem;">${escapeHtml(info.hostname)}</div>
              <div class="kpi-sub">${escapeHtml((info.ip_addresses || []).join(', ') || '127.0.0.1')}</div>
            </div>
            <div class="kpi-card">
              <div class="kpi-label">Distribution Linux</div>
              <div class="kpi-value" style="font-size:1.02rem;">${escapeHtml(info.os_name)}</div>
              <div class="kpi-sub">Kernel ${escapeHtml(info.kernel)} (${escapeHtml(info.arch)})</div>
            </div>
            <div class="kpi-card">
              <div class="kpi-label">Processeur & Mémoire</div>
              <div class="kpi-value" style="font-size:1.02rem;">${info.cpu_cores} Cœurs · ${formatBytes(info.memory_total)}</div>
              <div class="kpi-sub">${escapeHtml(info.cpu_model)}</div>
            </div>
            <div class="kpi-card">
              <div class="kpi-label">Stack Runtime</div>
              <div class="kpi-value" style="font-size:1.02rem;">PHP ${escapeHtml(info.php_version)}</div>
              <div class="kpi-sub">Uptime ${d}j ${h}h ${m}m · Caddy ${escapeHtml(info.caddy_version || 'Actif')}</div>
            </div>
          </div>
        </div>

        <div class="settings-card">
          <h3>Alimentation du Serveur</h3>
          <p class="desc">Un redémarrage basculera automatiquement votre PWA sur l'écran d'attente avec reconnexion automatique.</p>
          <div style="display:flex;gap:10px;flex-wrap:wrap;">
            <button type="button" class="os-btn os-btn-ghost" data-pwr="reboot">↻ Redémarrer le serveur Debian</button>
            <button type="button" class="os-btn os-btn-ghost" data-pwr="poweroff" style="color:var(--os-danger);">⏻ Éteindre la machine</button>
          </div>
        </div>
      `;

      pane.querySelectorAll('[data-pwr]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          const mode = btn.dataset.pwr;
          if (!window.confirm(`Confirmer l'action "${mode}" sur le serveur Debian ?`)) return;
          try {
            await api.post('/api/system.php?action=power', { mode });
            if (mode === 'reboot') window.location.href = '/offline.html';
          } catch (err) {
            notify(err.message, 'error');
          }
        });
      });
    } catch (err) {
      pane.innerHTML = `<div class="os-alert os-alert-error">${escapeHtml(err.message)}</div>`;
    }
  }

  // ==========================================================================
  // 2. STOCKAGE (LSBLK, MONTAGE /MNT/) & PARTAGES SAMBA SMB
  // ==========================================================================

  async function renderStorage() {
    try {
      const data = await api.get('/api/system.php?action=storage_overview');
      const devices = data.blockdevices || [];
      let shares = Array.isArray(data.samba?.shares) ? [...data.samba.shares] : [];

      const renderBlockRows = (list, depth = 0) => list.map((b) => {
        const canMount = b.fstype && !b.mountpoint && b.type !== 'disk';
        const canUmount = b.mountpoint && String(b.mountpoint).startsWith('/mnt/');
        return `
          <tr>
            <td style="padding-left:${13 + depth * 20}px;font-family:var(--font-mono);font-weight:${depth === 0 ? '700' : '400'};">
              ${depth > 0 ? '└─ ' : ''}${escapeHtml(b.name)}
            </td>
            <td>${escapeHtml(b.type)}</td>
            <td style="font-family:var(--font-mono);">${formatBytes(b.size)}</td>
            <td>${escapeHtml(b.fstype || '—')}</td>
            <td style="font-family:var(--font-mono);">${escapeHtml(b.mountpoint || 'Non monté')}</td>
            <td style="text-align:right;">
              ${canMount ? `<button type="button" class="btn-xs primary" data-mount-dev="${escapeHtml(b.path || '/dev/' + b.name)}" data-sug="${escapeHtml(b.label || b.name)}">Monter dans /mnt/</button>` : ''}
              ${canUmount ? `<button type="button" class="btn-xs danger" data-umount="${escapeHtml(b.mountpoint)}">Démonter</button>` : ''}
            </td>
          </tr>
          ${Array.isArray(b.children) ? renderBlockRows(b.children, depth + 1) : ''}
        `;
      }).join('');

      pane.innerHTML = `
        <div class="settings-card">
          <h3>Disques & Partitions (lsblk)</h3>
          <p class="desc">Montez ou démontez vos disques externes et volumes secondaires directement dans <code>/mnt/&lt;nom&gt;</code>.</p>
          ${devices.length === 0 ? `<p class="desc" style="margin:0;">Aucun périphérique bloc remonté (daemon Linux requis).</p>` : `
            <div class="clean-table-wrap">
              <table class="clean-table">
                <thead>
                  <tr>
                    <th>Périphérique</th>
                    <th>Type</th>
                    <th>Capacité</th>
                    <th>Système</th>
                    <th>Point de Montage</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>${renderBlockRows(devices)}</tbody>
              </table>
            </div>
          `}
        </div>

        <div class="settings-card">
          <div class="toolbar-row" style="margin-bottom:10px;">
            <div>
              <h3 style="margin:0;">Partages Réseau Samba (SMB / CIFS)</h3>
              <p class="desc" style="margin:2px 0 0;">Gérez vos dossiers partagés Windows / macOS / Linux (${data.samba?.installed ? 'Samba installé' : 'Paquet samba non détecté'}).</p>
            </div>
            <button type="button" class="btn-xs primary" id="addSmbShareBtn">+ Nouveau Partage</button>
          </div>

          <div id="smbSharesList" style="display:flex;flex-direction:column;gap:10px;"></div>
          <div style="margin-top:12px;">
            <button type="button" class="os-btn os-btn-primary" id="saveSmbBtn" style="width:auto;">Appliquer et recharger Samba</button>
          </div>
        </div>
      `;

      pane.querySelectorAll('[data-mount-dev]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          const folder = window.prompt('Nom du sous-dossier dans /mnt/ :', (btn.dataset.sug || 'data').replace(/[^a-zA-Z0-9_-]/g, ''));
          if (!folder) return;
          try {
            await api.post('/api/system.php?action=storage_mount', { source: btn.dataset.mountDev, folder });
            notify(`Volume monté sur /mnt/${folder}`);
            await renderStorage();
          } catch (err) {
            notify(err.message, 'error');
          }
        });
      });

      pane.querySelectorAll('[data-umount]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          const mp = btn.dataset.umount;
          if (!window.confirm(`Démonter ${mp} ?`)) return;
          try {
            await api.post('/api/system.php?action=storage_umount', { mountpoint: mp });
            notify(`${mp} démonté.`);
            await renderStorage();
          } catch (err) {
            notify(err.message, 'error');
          }
        });
      });

      const smbContainer = pane.querySelector('#smbSharesList');
      const paintShares = () => {
        if (shares.length === 0) {
          smbContainer.innerHTML = `<div style="font-size:0.82rem;color:var(--os-text-secondary);">Aucun partage Samba configuré.</div>`;
          return;
        }
        smbContainer.innerHTML = shares.map((s, idx) => `
          <div style="display:grid;grid-template-columns:150px 1fr auto auto auto;gap:8px;align-items:center;padding:10px;border-radius:12px;background:rgba(0,0,0,0.14);border:1px solid var(--os-border);">
            <input type="text" class="os-input" data-sidx="${idx}" data-sfield="name" value="${escapeHtml(s.name)}" placeholder="NomPartage" style="padding:7px 10px;">
            <input type="text" class="os-input" data-sidx="${idx}" data-sfield="path" value="${escapeHtml(s.path)}" placeholder="/mnt/disque" style="padding:7px 10px;font-family:var(--font-mono);">
            <label style="font-size:0.76rem;display:flex;align-items:center;gap:5px;"><input type="checkbox" data-sidx="${idx}" data-sfield="read_only" ${s.read_only ? 'checked' : ''}> Lecture seule</label>
            <label style="font-size:0.76rem;display:flex;align-items:center;gap:5px;"><input type="checkbox" data-sidx="${idx}" data-sfield="guest_ok" ${s.guest_ok ? 'checked' : ''}> Invité OK</label>
            <button type="button" class="btn-xs danger" data-del-smb="${idx}">✕</button>
          </div>
        `).join('');

        smbContainer.querySelectorAll('[data-sfield]').forEach((inp) => {
          inp.addEventListener('input', () => {
            const i = Number(inp.dataset.sidx);
            const f = inp.dataset.sfield;
            shares[i][f] = inp.type === 'checkbox' ? inp.checked : inp.value;
          });
        });

        smbContainer.querySelectorAll('[data-del-smb]').forEach((btn) => {
          btn.addEventListener('click', () => {
            shares.splice(Number(btn.dataset.delSmb), 1);
            paintShares();
          });
        });
      };

      paintShares();

      pane.querySelector('#addSmbShareBtn').addEventListener('click', () => {
        shares.push({ name: 'Media', path: '/mnt/media', read_only: false, guest_ok: false, browseable: true });
        paintShares();
      });

      pane.querySelector('#saveSmbBtn').addEventListener('click', async () => {
        try {
          await api.post('/api/system.php?action=samba_save', { shares });
          notify('Partages Samba enregistrés et service smbd rechargé.');
        } catch (err) {
          notify(err.message, 'error');
        }
      });
    } catch (err) {
      pane.innerHTML = `<div class="os-alert os-alert-error">${escapeHtml(err.message)}</div>`;
    }
  }

  // ==========================================================================
  // 3. RÉSEAU, VPN TAILSCALE & ISOLATION CADDY
  // ==========================================================================

  async function renderNetwork() {
    try {
      const data = await api.get('/api/system.php?action=network_security');
      const ifaces = data.network?.interfaces || [];
      const dns = data.network?.nameservers || [];
      const ts = data.tailscale || {};
      const osState = window.__VANILLIA_DESKTOP__?.state?.os || {};

      pane.innerHTML = `
        <div class="settings-card">
          <h3>Interfaces Réseau (${ifaces.length})</h3>
          <p class="desc">Serveurs DNS actifs : <code>${escapeHtml(dns.join(', ') || 'Système')}</code></p>

          <div class="cards-grid">
            ${ifaces.filter((i) => i.ifname !== 'lo').map((iface) => {
              const addrs = (iface.addr_info || []).map((a) => `${a.local}/${a.prefixlen}`).join(', ');
              return `
                <div class="entity-card">
                  <div style="display:flex;justify-content:space-between;">
                    <strong>${escapeHtml(iface.ifname)}</strong>
                    <span class="status-pill-sm ${iface.operstate === 'UP' ? 'status-running' : 'status-stopped'}">${escapeHtml(iface.operstate || 'UNKNOWN')}</span>
                  </div>
                  <div style="font-family:var(--font-mono);font-size:0.76rem;color:var(--os-text-secondary);">MAC : ${escapeHtml(iface.address || '—')}</div>
                  <div style="font-family:var(--font-mono);font-size:0.78rem;">${escapeHtml(addrs || 'Aucune IP assignée')}</div>
                </div>
              `;
            }).join('')}
          </div>
        </div>

        <div class="settings-card">
          <h3>Réseau Mesh VPN Tailscale</h3>
          ${!ts.installed ? `<p class="desc" style="margin:0;">Tailscale n'est pas installé sur ce serveur (<code>curl -fsSL https://tailscale.com/install.sh | sh</code>).</p>` : `
            <p class="desc">État : <strong>${escapeHtml(ts.backend_state)}</strong> · IPs Tailscale : <code>${escapeHtml((ts.tailscale_ips || []).join(', ') || '—')}</code> · Pairs : ${ts.peers_count || 0}</p>
            <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
              <input type="text" class="os-input" id="tsAuthKey" placeholder="tskey-auth-... (optionnel si déjà lié)" style="max-width:290px;">
              <button type="button" class="btn-xs primary" id="tsUpBtn">Connecter (tailscale up)</button>
              <button type="button" class="btn-xs danger" id="tsDownBtn">Déconnecter</button>
            </div>
          `}
        </div>

        <div class="settings-card">
          <h3>Isolation Réseau de l'Administration WebOS (Caddy)</h3>
          <p class="desc">Limitez l'accès au bureau Vanill-IA OS aux adresses IP privées LAN ou à votre VPN Tailscale tout en gardant vos conteneurs publics accessibles.</p>
          <div style="display:flex;gap:10px;flex-wrap:wrap;">
            <select class="os-select" id="netExposureSel" style="max-width:350px;">
              <option value="all" ${osState.network_exposure === 'all' ? 'selected' : ''}>Toutes les interfaces (WAN + LAN + Tailscale)</option>
              <option value="lan_tailscale" ${osState.network_exposure === 'lan_tailscale' ? 'selected' : ''}>LAN privé (RFC1918) + Tailscale uniquement</option>
              <option value="tailscale_only" ${osState.network_exposure === 'tailscale_only' ? 'selected' : ''}>VPN Tailscale (100.64.0.0/10) exclusivement</option>
            </select>
            <button type="button" class="os-btn os-btn-primary" id="applyExposureBtn" style="width:auto;">Appliquer dans Caddy</button>
          </div>
        </div>
      `;

      pane.querySelector('#tsUpBtn')?.addEventListener('click', async () => {
        try {
          await api.post('/api/system.php?action=tailscale_action', {
            subcommand: 'up',
            authkey: pane.querySelector('#tsAuthKey')?.value || '',
          });
          notify('Tailscale activé.');
          await renderNetwork();
        } catch (err) {
          notify(err.message, 'error');
        }
      });

      pane.querySelector('#tsDownBtn')?.addEventListener('click', async () => {
        try {
          await api.post('/api/system.php?action=tailscale_action', { subcommand: 'down' });
          notify('Tailscale déconnecté.');
          await renderNetwork();
        } catch (err) {
          notify(err.message, 'error');
        }
      });

      pane.querySelector('#applyExposureBtn')?.addEventListener('click', async () => {
        const mode = pane.querySelector('#netExposureSel').value;
        try {
          await api.post('/api/system.php?action=network_exposure', { mode });
          if (window.__VANILLIA_DESKTOP__?.state?.os) {
            window.__VANILLIA_DESKTOP__.state.os.network_exposure = mode;
          }
          notify('Isolation réseau Caddy mise à jour.');
        } catch (err) {
          notify(err.message, 'error');
        }
      });
    } catch (err) {
      pane.innerHTML = `<div class="os-alert os-alert-error">${escapeHtml(err.message)}</div>`;
    }
  }

  // ==========================================================================
  // 4. PARE-FEU UFW & PRISONS FAIL2BAN
  // ==========================================================================

  async function renderFirewall() {
    try {
      const data = await api.get('/api/system.php?action=network_security');
      const ufw = data.ufw || {};
      const f2b = data.fail2ban || {};

      pane.innerHTML = `
        <div class="settings-card">
          <div class="toolbar-row" style="margin-bottom:12px;">
            <div>
              <h3 style="margin:0;">Pare-feu UFW (Uncomplicated Firewall)</h3>
              <p class="desc" style="margin:2px 0 0;">Les ports critiques SSH (22) et WebOS (8443/8080) sont automatiquement protégés contre l'auto-blocage à l'activation.</p>
            </div>
            <button type="button" class="btn-xs ${ufw.active ? 'danger' : 'primary'}" id="toggleUfwBtn">
              ${ufw.active ? 'Désactiver UFW' : 'Activer le pare-feu UFW'}
            </button>
          </div>

          <form id="ufwRuleForm" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px;">
            <select class="os-select" name="operation" style="max-width:140px;">
              <option value="allow">Autoriser (ALLOW)</option>
              <option value="deny">Bloquer (DENY)</option>
              <option value="limit">Limiter (LIMIT)</option>
            </select>
            <input type="text" class="os-input" name="port" placeholder="Port ex: 443 ou 8000:8010" required style="max-width:210px;">
            <select class="os-select" name="proto" style="max-width:120px;">
              <option value="tcp">TCP</option>
              <option value="udp">UDP</option>
              <option value="any">TCP+UDP</option>
            </select>
            <button type="submit" class="btn-xs primary">+ Ajouter la règle</button>
          </form>

          ${(ufw.rules || []).length === 0 ? `<div style="font-size:0.82rem;color:var(--os-text-secondary);">Aucune règle UFW active.</div>` : `
            <div class="clean-table-wrap">
              <table class="clean-table">
                <thead>
                  <tr><th>#</th><th>Destination</th><th>Action</th><th>Source</th><th></th></tr>
                </thead>
                <tbody>
                  ${ufw.rules.map((r) => `
                    <tr>
                      <td style="font-family:var(--font-mono);">${r.number}</td>
                      <td style="font-family:var(--font-mono);font-weight:600;">${escapeHtml(r.to)}</td>
                      <td><span class="status-pill-sm ${r.action.includes('ALLOW') ? 'status-running' : 'status-error'}">${escapeHtml(r.action)}</span></td>
                      <td style="font-family:var(--font-mono);">${escapeHtml(r.from)}</td>
                      <td style="text-align:right;"><button type="button" class="btn-xs danger" data-del-ufw="${r.number}">Supprimer</button></td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            </div>
          `}
        </div>

        <div class="settings-card">
          <h3>Protection Intrusion Fail2ban</h3>
          <p class="desc">Surveille notamment <code>/var/log/vanill-ia-auth.log</code> (prison <code>vanill-ia-os</code>) et SSH.</p>

          ${!f2b.running ? `<div style="font-size:0.82rem;color:var(--os-text-secondary);">Service Fail2ban non démarré ou non installé.</div>` : `
            <div class="cards-grid">
              ${(f2b.jails || []).map((j) => `
                <div class="entity-card">
                  <div style="display:flex;justify-content:space-between;">
                    <strong>Jail : ${escapeHtml(j.name)}</strong>
                    <span class="status-pill-sm ${j.currently_banned > 0 ? 'status-error' : 'status-running'}">${j.currently_banned} banni(s)</span>
                  </div>
                  <div style="font-size:0.76rem;color:var(--os-text-secondary);">Total historique banni : ${j.total_banned}</div>
                  ${(j.banned_ips || []).length > 0 ? `
                    <div style="display:flex;flex-wrap:wrap;gap:6px;">
                      ${j.banned_ips.map((ip) => `
                        <button type="button" class="btn-xs danger" data-unban-ip="${escapeHtml(ip)}" data-unban-jail="${escapeHtml(j.name)}">
                          Débannir ${escapeHtml(ip)} ✕
                        </button>
                      `).join('')}
                    </div>
                  ` : `<div style="font-size:0.76rem;color:var(--os-text-muted);">Aucune IP bannie actuellement.</div>`}
                </div>
              `).join('')}
            </div>
          `}
        </div>
      `;

      pane.querySelector('#toggleUfwBtn').addEventListener('click', async () => {
        try {
          await api.post('/api/system.php?action=ufw_toggle', { enable: !ufw.active });
          notify(`Pare-feu UFW ${!ufw.active ? 'activé' : 'désactivé'}.`);
          await renderFirewall();
        } catch (err) {
          notify(err.message, 'error');
        }
      });

      pane.querySelector('#ufwRuleForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const fd = new FormData(e.currentTarget);
        try {
          await api.post('/api/system.php?action=ufw_rule', {
            operation: fd.get('operation'),
            port: fd.get('port'),
            proto: fd.get('proto'),
          });
          notify('Règle UFW appliquée.');
          await renderFirewall();
        } catch (err) {
          notify(err.message, 'error');
        }
      });

      pane.querySelectorAll('[data-del-ufw]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          try {
            await api.post('/api/system.php?action=ufw_rule', {
              operation: 'delete',
              number: Number(btn.dataset.delUfw),
            });
            notify('Règle UFW supprimée.');
            await renderFirewall();
          } catch (err) {
            notify(err.message, 'error');
          }
        });
      });

      pane.querySelectorAll('[data-unban-ip]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          try {
            await api.post('/api/system.php?action=fail2ban_unban', {
              jail: btn.dataset.unbanJail,
              ip: btn.dataset.unbanIp,
            });
            notify(`IP ${btn.dataset.unbanIp} débannie.`);
            await renderFirewall();
          } catch (err) {
            notify(err.message, 'error');
          }
        });
      });
    } catch (err) {
      pane.innerHTML = `<div class="os-alert os-alert-error">${escapeHtml(err.message)}</div>`;
    }
  }

  // ==========================================================================
  // 5. SERVICES SYSTEMD & JOURNALCTL (+ DIAGNOSTIC IA)
  // ==========================================================================

  async function renderServices(filterText = '', onlyFailed = false) {
    try {
      const res = await api.get(`/api/system.php?action=services_list&search=${encodeURIComponent(filterText)}`);
      let services = res.services || [];
      if (onlyFailed) {
        services = services.filter((s) => s.active === 'failed' || s.sub === 'failed');
      }

      pane.innerHTML = `
        <div class="toolbar-row">
          <div style="display:flex;gap:8px;flex:1;flex-wrap:wrap;">
            <input type="search" class="os-input" id="svcSearchInput" value="${escapeHtml(filterText)}" placeholder="Rechercher un service (caddy, ssh, docker, php...)" style="max-width:310px;padding:7px 12px;">
            <label style="display:flex;align-items:center;gap:6px;font-size:0.82rem;cursor:pointer;">
              <input type="checkbox" id="svcOnlyFailed" ${onlyFailed ? 'checked' : ''}>
              Afficher uniquement les services en échec
            </label>
          </div>
          <button type="button" class="btn-xs" id="svcRefreshBtn">↻ Actualiser</button>
        </div>

        <div class="clean-table-wrap">
          <table class="clean-table">
            <thead>
              <tr><th>Unité Systemd</th><th>État</th><th>Description</th><th style="text-align:right;">Actions</th></tr>
            </thead>
            <tbody>
              ${services.length === 0 ? `<tr><td colspan="4" style="text-align:center;color:var(--os-text-secondary);padding:20px;">Aucun service trouvé.</td></tr>` : services.slice(0, 120).map((s) => {
                const isRunning = s.active === 'active';
                const isFailed = s.active === 'failed';
                return `
                  <tr>
                    <td style="font-family:var(--font-mono);font-weight:600;">${escapeHtml(s.unit)}</td>
                    <td>
                      <span class="status-pill-sm ${isRunning ? 'status-running' : isFailed ? 'status-error' : 'status-stopped'}">
                        ${escapeHtml(s.active)} (${escapeHtml(s.sub)})
                      </span>
                    </td>
                    <td style="color:var(--os-text-secondary);max-width:260px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${escapeHtml(s.description)}</td>
                    <td style="text-align:right;white-space:nowrap;">
                      <button type="button" class="btn-xs" data-unit="${escapeHtml(s.unit)}" data-uop="restart">↻</button>
                      ${isRunning
                        ? `<button type="button" class="btn-xs" data-unit="${escapeHtml(s.unit)}" data-uop="stop">⏹</button>`
                        : `<button type="button" class="btn-xs primary" data-unit="${escapeHtml(s.unit)}" data-uop="start">▶</button>`
                      }
                      <button type="button" class="btn-xs" data-svc-logs="${escapeHtml(s.unit)}">Logs</button>
                      <button type="button" class="btn-xs ai-diag" data-svc-ai="${escapeHtml(s.unit)}">✨ IA</button>
                    </td>
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>
        </div>
      `;

      const searchInp = pane.querySelector('#svcSearchInput');
      const failChk = pane.querySelector('#svcOnlyFailed');

      searchInp.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') renderServices(searchInp.value, failChk.checked);
      });
      failChk.addEventListener('change', () => renderServices(searchInp.value, failChk.checked));
      pane.querySelector('#svcRefreshBtn').addEventListener('click', () => renderServices(searchInp.value, failChk.checked));

      pane.querySelectorAll('[data-uop]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          try {
            await api.post('/api/system.php?action=service_action', {
              unit: btn.dataset.unit,
              operation: btn.dataset.uop,
            });
            notify(`Action ${btn.dataset.uop} exécutée sur ${btn.dataset.unit}.`);
            await renderServices(searchInp.value, failChk.checked);
          } catch (err) {
            notify(err.message, 'error');
          }
        });
      });

      pane.querySelectorAll('[data-svc-logs]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          const unit = btn.dataset.svcLogs;
          try {
            const resLogs = await api.get(`/api/system.php?action=service_logs&unit=${encodeURIComponent(unit)}&lines=180`);
            modalSlot.innerHTML = `
              <div class="inwin-modal-backdrop">
                <div class="inwin-modal">
                  <div class="inwin-modal-header">
                    <span>journalctl — ${escapeHtml(unit)}</span>
                    <div style="display:flex;gap:8px;">
                      <button type="button" class="btn-xs ai-diag" id="diagSvcModalBtn">✨ Diagnostiquer avec Vanill-IA</button>
                      <button type="button" class="btn-xs" id="closeSvcModalBtn">Fermer</button>
                    </div>
                  </div>
                  <div class="inwin-modal-body">
                    <pre class="log-console selectable">${escapeHtml(resLogs.logs || '(Aucun log)')}</pre>
                  </div>
                </div>
              </div>
            `;
            modalSlot.querySelector('#closeSvcModalBtn').addEventListener('click', () => { modalSlot.innerHTML = ''; });
            modalSlot.querySelector('#diagSvcModalBtn').addEventListener('click', () => {
              modalSlot.innerHTML = '';
              window.__VANILLIA_DESKTOP__?.launchAppById('vanill-ia-chat', {
                context_type: 'systemd_diag',
                target: unit,
                logs: resLogs.logs || '',
              });
            });
          } catch (err) {
            notify(err.message, 'error');
          }
        });
      });

      pane.querySelectorAll('[data-svc-ai]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          const unit = btn.dataset.svcAi;
          const resLogs = await api.get(`/api/system.php?action=service_logs&unit=${encodeURIComponent(unit)}&lines=120`);
          window.__VANILLIA_DESKTOP__?.launchAppById('vanill-ia-chat', {
            context_type: 'systemd_diag',
            target: unit,
            logs: resLogs.logs || '',
          });
        });
      });
    } catch (err) {
      pane.innerHTML = `<div class="os-alert os-alert-error">${escapeHtml(err.message)}</div>`;
    }
  }

  // ==========================================================================
  // 6. GESTIONNAIRE DE MISES À JOUR APT
  // ==========================================================================

  async function renderApt(refresh = false) {
    if (refresh) {
      pane.innerHTML = `<div class="settings-card">Exécution de <code>apt-get update</code> sur les dépôts Debian...</div>`;
    }
    try {
      const data = await api.get(`/api/system.php?action=apt_status${refresh ? '&refresh=1' : ''}`);
      const pkgs = data.packages || [];

      pane.innerHTML = `
        ${data.reboot_required ? `<div class="os-alert os-alert-info">⚠️ Une mise à jour récente du noyau Linux requiert un redémarrage du serveur (<code>/var/run/reboot-required</code>).</div>` : ''}

        <div class="settings-card">
          <div class="toolbar-row">
            <div>
              <h3 style="margin:0;">Mises à jour Système Debian (${pkgs.length} disponible${pkgs.length > 1 ? 's' : ''})</h3>
              <p class="desc" style="margin:2px 0 0;">Mise à niveau non-interactive sécurisée conservant vos fichiers de configuration existants.</p>
            </div>
            <div style="display:flex;gap:8px;">
              <button type="button" class="btn-xs" id="aptRefreshBtn">🔍 Vérifier (apt update)</button>
              ${pkgs.length > 0 ? `<button type="button" class="btn-xs primary" id="aptUpgradeBtn">⬆️ Tout mettre à jour (${pkgs.length})</button>` : ''}
            </div>
          </div>

          ${pkgs.length === 0 ? `<p style="margin-top:14px;font-size:0.84rem;color:var(--os-success);font-weight:600;">✓ Tous les paquets Debian sont à jour.</p>` : `
            <div class="clean-table-wrap" style="margin-top:14px;">
              <table class="clean-table">
                <thead>
                  <tr><th>Paquet</th><th>Version Actuelle</th><th>Nouvelle Version</th><th>Branche / Arch</th></tr>
                </thead>
                <tbody>
                  ${pkgs.map((p) => `
                    <tr>
                      <td style="font-family:var(--font-mono);font-weight:600;">${escapeHtml(p.name)}</td>
                      <td style="font-family:var(--font-mono);color:var(--os-text-secondary);">${escapeHtml(p.current_version)}</td>
                      <td style="font-family:var(--font-mono);color:var(--os-success);font-weight:600;">${escapeHtml(p.new_version)}</td>
                      <td>${escapeHtml(p.suite)} (${escapeHtml(p.arch)})</td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            </div>
          `}

          <pre class="log-console hidden selectable" id="aptUpgradeConsole" style="margin-top:14px;"></pre>
        </div>
      `;

      pane.querySelector('#aptRefreshBtn').addEventListener('click', () => renderApt(true));
      pane.querySelector('#aptUpgradeBtn')?.addEventListener('click', async (e) => {
        const btn = e.currentTarget;
        if (!window.confirm(`Installer les ${pkgs.length} mises à jour Debian maintenant ?`)) return;
        btn.disabled = true;
        const out = pane.querySelector('#aptUpgradeConsole');
        out.classList.remove('hidden');
        out.textContent = 'Installation des mises à jour en cours via apt-get upgrade (cela peut prendre quelques minutes)...';
        try {
          const res = await api.post('/api/system.php?action=apt_upgrade');
          out.textContent = res.output || 'Mise à niveau terminée avec succès.';
          notify('Système Debian mis à jour avec succès !');
        } catch (err) {
          out.textContent = `[ERREUR] ${err.message}`;
          notify(err.message, 'error');
          btn.disabled = false;
        }
      });
    } catch (err) {
      pane.innerHTML = `<div class="os-alert os-alert-error">${escapeHtml(err.message)}</div>`;
    }
  }

  // ==========================================================================
  // 7. SÉCURITÉ 2FA TOTP, APPARENCE & JOURNAL D'AUDIT
  // ==========================================================================

  async function renderSecurityAndAppearance() {
    const user = window.__VANILLIA_DESKTOP__?.state?.user || {};
    let auditLogs = [];
    try {
      const aRes = await api.get('/api/system.php?action=audit_logs');
      auditLogs = aRes.logs || [];
    } catch (_) {}

    const wallpapers = [
      { id: 'aurora-coral', label: 'Aurora Coral', bg: 'linear-gradient(135deg, #FF6D5A 0%, #1E293B 60%, #0EA5E9 100%)' },
      { id: 'midnight-slate', label: 'Midnight Slate', bg: 'linear-gradient(135deg, #0F172A 0%, #2563EB 100%)' },
      { id: 'umbrel-twilight', label: 'Umbrel Twilight', bg: 'linear-gradient(135deg, #7C3AED 0%, #EC4899 100%)' },
      { id: 'emerald-abyss', label: 'Emerald Abyss', bg: 'linear-gradient(135deg, #064E3B 0%, #14B8A6 100%)' },
      { id: 'solar-sand', label: 'Solar Sand', bg: 'linear-gradient(135deg, #F59E0B 0%, #FF6D5A 100%)' },
    ];

    pane.innerHTML = `
      <div class="settings-card">
        <h3>Apparence & Verrouillage Automatique DSM</h3>
        <p class="desc">Personnalisez votre environnement de travail WebOS et la mise en veille sécurisée.</p>

        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px;margin-bottom:16px;">
          <div>
            <label class="form-label">Thème d'interface</label>
            <select class="os-select" id="secThemeMode">
              <option value="dark" ${user.theme_mode === 'dark' ? 'selected' : ''}>Mode Sombre (#0F1115)</option>
              <option value="light" ${user.theme_mode === 'light' ? 'selected' : ''}>Mode Clair (Alabaster)</option>
            </select>
          </div>
          <div>
            <label class="form-label">Verrouillage auto d'inactivité</label>
            <select class="os-select" id="secLockMin">
              <option value="5" ${user.session_lock_minutes === 5 ? 'selected' : ''}>5 minutes</option>
              <option value="15" ${user.session_lock_minutes === 15 ? 'selected' : ''}>15 minutes</option>
              <option value="30" ${user.session_lock_minutes === 30 ? 'selected' : ''}>30 minutes</option>
              <option value="60" ${user.session_lock_minutes === 60 ? 'selected' : ''}>1 heure</option>
              <option value="0" ${user.session_lock_minutes === 0 ? 'selected' : ''}>Désactivé</option>
            </select>
          </div>
        </div>

        <div class="wallpaper-swatches">
          ${wallpapers.map((w) => `
            <button type="button" class="wp-swatch ${user.wallpaper === w.id ? 'active' : ''}" data-wp-pick="${w.id}" style="background:${w.bg}">
              ${w.label}
            </button>
          `).join('')}
        </div>
      </div>

      <div class="settings-card">
        <h3>Double Authentification 2FA (TOTP RFC 6238)</h3>
        <p class="desc">QR Code SVG généré localement sur votre serveur Debian, sans dépendance externe.</p>
        <div id="secTotpBox"></div>
      </div>

      <div class="settings-card">
        <h3>Journal d'Audit de Sécurité (${auditLogs.length})</h3>
        <div class="clean-table-wrap" style="margin-top:8px;max-height:240px;overflow-y:auto;">
          <table class="clean-table">
            <thead>
              <tr><th>Horodatage UTC</th><th>Utilisateur</th><th>IP</th><th>Action</th><th>Cible</th></tr>
            </thead>
            <tbody>
              ${auditLogs.map((l) => `
                <tr>
                  <td style="font-family:var(--font-mono);font-size:0.74rem;">${escapeHtml(l.created_at)}</td>
                  <td>${escapeHtml(l.username)}</td>
                  <td style="font-family:var(--font-mono);">${escapeHtml(l.ip_address || '')}</td>
                  <td><span class="status-pill-sm status-info">${escapeHtml(l.action)}</span></td>
                  <td style="font-family:var(--font-mono);font-size:0.75rem;">${escapeHtml(l.target || '—')}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;

    const savePrefs = async (patch) => {
      try {
        const res = await api.post('/api/auth.php?action=preferences', patch);
        window.__VANILLIA_DESKTOP__?.applyUserPreferences(res.user);
        notify('Préférences enregistrées.');
      } catch (err) {
        notify(err.message, 'error');
      }
    };

    pane.querySelector('#secThemeMode').addEventListener('change', (e) => savePrefs({ theme_mode: e.target.value }));
    pane.querySelector('#secLockMin').addEventListener('change', (e) => savePrefs({ session_lock_minutes: Number(e.target.value) }));
    pane.querySelectorAll('[data-wp-pick]').forEach((btn) => {
      btn.addEventListener('click', () => {
        pane.querySelectorAll('[data-wp-pick]').forEach((b) => b.classList.toggle('active', b === btn));
        savePrefs({ wallpaper: btn.dataset.wpPick });
      });
    });

    const totpBox = pane.querySelector('#secTotpBox');
    const paintTotp = () => {
      const isEnabled = Boolean(window.__VANILLIA_DESKTOP__?.state?.user?.totp_enabled);
      if (isEnabled) {
        totpBox.innerHTML = `
          <div class="os-alert os-alert-info">✓ La double authentification 2FA TOTP est active.</div>
          <div style="display:flex;gap:8px;flex-wrap:wrap;">
            <input type="password" class="os-input" id="disPass" placeholder="Mot de passe actuel" style="max-width:210px;">
            <input type="text" class="os-input code-totp" id="disCode" placeholder="Code 2FA" maxlength="9" style="max-width:160px;">
            <button type="button" class="btn-xs danger" id="disBtn">Désactiver le 2FA</button>
          </div>
        `;
        totpBox.querySelector('#disBtn').addEventListener('click', async () => {
          try {
            await api.post('/api/auth.php?action=totp_disable', {
              password: totpBox.querySelector('#disPass').value,
              totp_code: totpBox.querySelector('#disCode').value,
            });
            window.__VANILLIA_DESKTOP__.state.user.totp_enabled = false;
            notify('2FA désactivé.');
            paintTotp();
          } catch (err) {
            notify(err.message, 'error');
          }
        });
      } else {
        totpBox.innerHTML = `<button type="button" class="os-btn os-btn-primary" id="enStartBtn" style="width:auto;">Activer le 2FA TOTP</button>`;
        totpBox.querySelector('#enStartBtn').addEventListener('click', async () => {
          const prep = await api.post('/api/auth.php?action=totp_prepare');
          totpBox.innerHTML = `
            <div class="totp-setup-box">
              <div class="qr-frame">${renderQrCodeSvg(prep.otpauth_uri)}</div>
              <p style="text-align:center;font-family:var(--font-mono);font-size:0.76rem;margin-bottom:10px;" class="selectable">Clé : ${prep.secret}</p>
              <div style="display:flex;gap:8px;flex-wrap:wrap;justify-content:center;">
                <input type="password" class="os-input" id="enPass" placeholder="Mot de passe" style="max-width:200px;">
                <input type="text" class="os-input code-totp" id="enCode" placeholder="000000" maxlength="6" style="max-width:150px;">
                <button type="button" class="os-btn os-btn-primary" id="enConfirmBtn" style="width:auto;">Confirmer</button>
              </div>
            </div>
          `;
          totpBox.querySelector('#enConfirmBtn').addEventListener('click', async () => {
            try {
              const res = await api.post('/api/auth.php?action=totp_enable', {
                password: totpBox.querySelector('#enPass').value,
                totp_code: totpBox.querySelector('#enCode').value,
              });
              window.__VANILLIA_DESKTOP__.state.user.totp_enabled = true;
              totpBox.innerHTML = `
                <div class="os-alert os-alert-info"><strong>2FA activé !</strong> Copiez vos codes de secours uniques :</div>
                <div class="backup-codes-grid selectable">${res.backup_codes.map((c) => `<div class="backup-code-chip">${c}</div>`).join('')}</div>
              `;
            } catch (err) {
              notify(err.message, 'error');
            }
          });
        });
      }
    };
    paintTotp();
  }

  await switchSection(activeSection);

  return {
    onLaunch(newParams) {
      if (newParams?.section) switchSection(newParams.section);
    },
  };
}
