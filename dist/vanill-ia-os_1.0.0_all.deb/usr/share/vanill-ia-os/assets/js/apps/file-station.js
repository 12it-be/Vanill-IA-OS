/**
 * ==============================================================================
 * Vanill-IA OS — Step 5: File Station (Synology DSM Style Explorer)
 * - Breadcrumb navigation + Quick Bookmarks
 * - Drag & Drop Multi-File Upload + Direct Download
 * - Zip / Unzip Archives + Chmod / Chown Permissions Modal
 * - Media Preview (Images, PDF, Video, Audio) + Direct Launch in Code Editor
 * ==============================================================================
 */

function escapeHtml(str) {
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function formatBytes(bytes) {
  const n = Number(bytes) || 0;
  if (n === 0) return '—';
  if (n < 1024) return `${n} o`;
  if (n < 1048576) return `${(n / 1024).toFixed(1)} Ko`;
  if (n < 1073741824) return `${(n / 1048576).toFixed(1)} Mo`;
  return `${(n / 1073741824).toFixed(2)} Go`;
}

const TEXT_EXTS = new Set([
  'txt', 'md', 'yml', 'yaml', 'json', 'xml', 'php', 'js', 'mjs', 'ts', 'css', 'html',
  'sh', 'bash', 'zsh', 'py', 'conf', 'caddy', 'ini', 'env', 'sql', 'log', 'service', 'local', 'toml',
]);
const IMG_EXTS = new Set(['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg']);
const VIDEO_EXTS = new Set(['mp4', 'webm']);
const AUDIO_EXTS = new Set(['mp3', 'wav', 'ogg']);

function getFileEmoji(item) {
  if (item.is_dir) return '📁';
  const ext = item.extension || '';
  if (IMG_EXTS.has(ext)) return '🖼️';
  if (ext === 'pdf') return '📕';
  if (VIDEO_EXTS.has(ext)) return '🎬';
  if (AUDIO_EXTS.has(ext)) return '🎵';
  if (ext === 'zip' || ext === 'tar' || ext === 'gz') return '🗜️';
  if (TEXT_EXTS.has(ext) || item.name.startsWith('.')) return '📄';
  return '📦';
}

export async function mountApp({ container, api, params }) {
  let currentPath = params?.path || '/opt/vanill-ia/stacks';
  let items = [];
  let showHidden = false;
  let searchFilter = '';

  const bookmarks = [
    { label: '🏠 Racine /', path: '/' },
    { label: '🐳 Stacks Docker', path: '/opt/vanill-ia/stacks' },
    { label: '💾 Disques /mnt', path: '/mnt' },
    { label: '🔒 Caddy Conf', path: '/etc/caddy/conf.d' },
    { label: '📝 Notes .md', path: '/var/lib/vanill-ia-os/notes' },
    { label: '📜 Journaux /var/log', path: '/var/log' },
    { label: '👤 /root', path: '/root' },
  ];

  container.innerHTML = `
    <div class="module-layout" id="fsDropZone">
      <aside class="module-sidebar">
        <div style="font-size:0.72rem;font-weight:700;color:var(--os-text-muted);padding:4px 10px;text-transform:uppercase;">Emplacements</div>
        ${bookmarks.map((b) => `
          <button type="button" class="module-nav-btn" data-bm="${escapeHtml(b.path)}">${escapeHtml(b.label)}</button>
        `).join('')}
      </aside>
      <div class="module-content" id="fsContent"></div>
    </div>
    <input type="file" id="fsUploadInput" multiple class="hidden">
    <div id="fsModalSlot"></div>
  `;

  const contentEl = container.querySelector('#fsContent');
  const uploadInput = container.querySelector('#fsUploadInput');
  const modalSlot = container.querySelector('#fsModalSlot');
  const dropZone = container.querySelector('#fsDropZone');
  const notify = (msg, type = 'info') => window.__VANILLIA_DESKTOP__?.toast(msg, type);

  container.querySelectorAll('[data-bm]').forEach((btn) => {
    btn.addEventListener('click', () => navigate(btn.dataset.bm));
  });

  // Upload Drag & Drop sur toute la fenêtre File Station
  dropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropZone.style.outline = '2px dashed var(--os-accent)';
  });
  dropZone.addEventListener('dragleave', () => {
    dropZone.style.outline = 'none';
  });
  dropZone.addEventListener('drop', async (e) => {
    e.preventDefault();
    dropZone.style.outline = 'none';
    if (e.dataTransfer?.files?.length) {
      await uploadFiles(e.dataTransfer.files);
    }
  });

  uploadInput.addEventListener('change', async () => {
    if (uploadInput.files?.length) {
      await uploadFiles(uploadInput.files);
      uploadInput.value = '';
    }
  });

  async function uploadFiles(fileList) {
    const fd = new FormData();
    fd.append('dir', currentPath);
    for (const f of fileList) {
      fd.append('files[]', f);
    }
    try {
      notify(`Importation de ${fileList.length} fichier(s)...`);
      const res = await api.post('/api/files.php?action=upload', fd);
      notify(`${(res.uploaded || []).length} fichier(s) transféré(s) dans ${currentPath}.`);
      await navigate(currentPath);
    } catch (err) {
      notify(err.message, 'error');
    }
  }

  async function navigate(targetPath) {
    try {
      const res = await api.get(`/api/files.php?action=list&path=${encodeURIComponent(targetPath)}${showHidden ? '&hidden=1' : ''}`);
      currentPath = res.path || targetPath;
      items = res.items || [];

      container.querySelectorAll('[data-bm]').forEach((b) => {
        b.classList.toggle('active', b.dataset.bm === currentPath);
      });

      renderExplorer();
    } catch (err) {
      // Fallback sur / si le dossier initial n'existe pas encore
      if (targetPath !== '/') {
        await navigate('/');
      } else {
        contentEl.innerHTML = `<div class="os-alert os-alert-error">${escapeHtml(err.message)}</div>`;
      }
    }
  }

  function buildBreadcrumbsHtml(pathStr) {
    const parts = pathStr.split('/').filter(Boolean);
    let acc = '';
    let html = `<button type="button" class="btn-xs" data-crumb="/">/</button>`;
    for (const part of parts) {
      acc += '/' + part;
      html += `<span style="color:var(--os-text-muted);">›</span><button type="button" class="btn-xs" data-crumb="${escapeHtml(acc)}">${escapeHtml(part)}</button>`;
    }
    return html;
  }

  function renderExplorer() {
    const filtered = items.filter((it) => searchFilter === '' || it.name.toLowerCase().includes(searchFilter));

    contentEl.innerHTML = `
      <div class="toolbar-row">
        <div style="display:flex;align-items:center;gap:5px;flex-wrap:wrap;">
          ${buildBreadcrumbsHtml(currentPath)}
        </div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;">
          <button type="button" class="btn-xs primary" id="fsBtnUpload">⬆️ Importer (Drag & Drop)</button>
          <button type="button" class="btn-xs" id="fsBtnNewFolder">+ Dossier</button>
          <button type="button" class="btn-xs" id="fsBtnNewFile">+ Fichier</button>
          <label class="btn-xs" style="cursor:pointer;">
            <input type="checkbox" id="fsChkHidden" ${showHidden ? 'checked' : ''}> Cachés
          </label>
          <button type="button" class="btn-xs" id="fsBtnRefresh">↻</button>
        </div>
      </div>

      <div class="toolbar-row">
        <input type="search" class="os-input" id="fsFilterInp" value="${escapeHtml(searchFilter)}" placeholder="Filtrer dans ce dossier..." style="max-width:280px;padding:7px 12px;font-size:0.82rem;">
        <span style="font-size:0.76rem;color:var(--os-text-secondary);">${filtered.length} élément(s)</span>
      </div>

      <div class="clean-table-wrap">
        <table class="clean-table">
          <thead>
            <tr>
              <th>Nom</th>
              <th>Taille</th>
              <th>Permissions</th>
              <th>Propriétaire</th>
              <th style="text-align:right;">Actions</th>
            </tr>
          </thead>
          <tbody>
            ${currentPath !== '/' ? `
              <tr style="cursor:pointer;" id="fsParentRow">
                <td colspan="5" style="font-weight:600;color:var(--os-text-secondary);">↩ .. (Dossier parent)</td>
              </tr>
            ` : ''}
            ${filtered.length === 0 ? `<tr><td colspan="5" style="text-align:center;padding:24px;color:var(--os-text-secondary);">Dossier vide (glissez-déposez des fichiers ici pour les envoyer).</td></tr>` : filtered.map((it, idx) => `
              <tr data-item-idx="${idx}" style="cursor:pointer;">
                <td data-open-row="${idx}">
                  <span style="margin-right:8px;">${getFileEmoji(it)}</span>
                  <strong style="font-weight:${it.is_dir ? '600' : '500'};">${escapeHtml(it.name)}</strong>
                  ${it.is_symlink ? `<span class="status-pill-sm status-info" style="margin-left:6px;">lien</span>` : ''}
                </td>
                <td style="font-family:var(--font-mono);font-size:0.77rem;">${it.is_dir ? '—' : formatBytes(it.size)}</td>
                <td style="font-family:var(--font-mono);font-size:0.76rem;color:var(--os-text-secondary);">${escapeHtml(it.mode)}</td>
                <td style="font-family:var(--font-mono);font-size:0.76rem;color:var(--os-text-secondary);">${escapeHtml(it.owner)}:${escapeHtml(it.group)}</td>
                <td style="text-align:right;white-space:nowrap;">
                  ${!it.is_dir ? `<a href="/api/files.php?action=download&path=${encodeURIComponent(it.path)}" class="btn-xs" style="text-decoration:none;" title="Télécharger">⬇️</a>` : ''}
                  ${it.extension === 'zip'
                    ? `<button type="button" class="btn-xs" data-fs-act="unzip" data-idx="${idx}" title="Extraire ici">📦 Extraire</button>`
                    : `<button type="button" class="btn-xs" data-fs-act="zip" data-idx="${idx}" title="Compresser en .zip">🗜️ Zip</button>`
                  }
                  <button type="button" class="btn-xs" data-fs-act="perms" data-idx="${idx}" title="Permissions chmod/chown">🔐</button>
                  <button type="button" class="btn-xs" data-fs-act="rename" data-idx="${idx}" title="Renommer">✎</button>
                  <button type="button" class="btn-xs danger" data-fs-act="delete" data-idx="${idx}" title="Supprimer">✕</button>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;

    contentEl.querySelectorAll('[data-crumb]').forEach((b) => {
      b.addEventListener('click', () => navigate(b.dataset.crumb));
    });

    contentEl.querySelector('#fsParentRow')?.addEventListener('click', () => {
      const parent = currentPath.substring(0, currentPath.lastIndexOf('/')) || '/';
      navigate(parent);
    });

    contentEl.querySelector('#fsBtnUpload').addEventListener('click', () => uploadInput.click());
    contentEl.querySelector('#fsBtnRefresh').addEventListener('click', () => navigate(currentPath));
    contentEl.querySelector('#fsChkHidden').addEventListener('change', (e) => {
      showHidden = e.target.checked;
      navigate(currentPath);
    });

    const filterInp = contentEl.querySelector('#fsFilterInp');
    filterInp.addEventListener('input', () => {
      searchFilter = filterInp.value.toLowerCase();
      renderExplorer();
      const nf = contentEl.querySelector('#fsFilterInp');
      nf?.focus();
      nf?.setSelectionRange(nf.value.length, nf.value.length);
    });

    contentEl.querySelector('#fsBtnNewFolder').addEventListener('click', async () => {
      const name = window.prompt('Nom du nouveau dossier :');
      if (!name) return;
      try {
        const target = (currentPath === '/' ? '' : currentPath) + '/' + name.trim();
        await api.post('/api/files.php?action=mkdir', { path: target });
        notify('Dossier créé.');
        await navigate(currentPath);
      } catch (err) {
        notify(err.message, 'error');
      }
    });

    contentEl.querySelector('#fsBtnNewFile').addEventListener('click', async () => {
      const name = window.prompt('Nom du nouveau fichier (ex: script.sh ou config.yml) :');
      if (!name) return;
      const target = (currentPath === '/' ? '' : currentPath) + '/' + name.trim();
      try {
        await api.post('/api/files.php?action=write', { path: target, content: '' });
        await navigate(currentPath);
        window.__VANILLIA_DESKTOP__?.launchAppById('code-editor', { path: target });
      } catch (err) {
        notify(err.message, 'error');
      }
    });

    // Clic sur une ligne : Navigation dossier, Aperçu média ou Éditeur de Code
    contentEl.querySelectorAll('[data-open-row]').forEach((cell) => {
      cell.addEventListener('click', () => {
        const it = filtered[Number(cell.dataset.openRow)];
        if (!it) return;
        if (it.is_dir) {
          navigate(it.path);
          return;
        }
        const ext = it.extension || '';
        if (IMG_EXTS.has(ext) || ext === 'pdf' || VIDEO_EXTS.has(ext) || AUDIO_EXTS.has(ext)) {
          openMediaPreviewModal(it);
          return;
        }
        window.__VANILLIA_DESKTOP__?.launchAppById('code-editor', { path: it.path });
      });
    });

    // Actions par élément
    contentEl.querySelectorAll('[data-fs-act]').forEach((btn) => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const it = filtered[Number(btn.dataset.idx)];
        if (!it) return;
        const act = btn.dataset.fsAct;

        if (act === 'rename') {
          const nextName = window.prompt('Nouveau nom :', it.name);
          if (!nextName || nextName === it.name) return;
          const dest = (currentPath === '/' ? '' : currentPath) + '/' + nextName.trim();
          try {
            await api.post('/api/files.php?action=rename', { from: it.path, to: dest });
            notify('Élément renommé.');
            await navigate(currentPath);
          } catch (err) {
            notify(err.message, 'error');
          }
        } else if (act === 'delete') {
          if (!window.confirm(`Supprimer définitivement "${it.name}" ?`)) return;
          try {
            await api.post('/api/files.php?action=delete', { path: it.path });
            notify('Élément supprimé.');
            await navigate(currentPath);
          } catch (err) {
            notify(err.message, 'error');
          }
        } else if (act === 'zip') {
          try {
            await api.post('/api/files.php?action=archive', { mode: 'zip', source: it.path, destination: `${it.path}.zip` });
            notify(`Archive créée : ${it.name}.zip`);
            await navigate(currentPath);
          } catch (err) {
            notify(err.message, 'error');
          }
        } else if (act === 'unzip') {
          try {
            await api.post('/api/files.php?action=archive', { mode: 'unzip', source: it.path, destination: currentPath });
            notify('Archive extraite.');
            await navigate(currentPath);
          } catch (err) {
            notify(err.message, 'error');
          }
        } else if (act === 'perms') {
          openPermsModal(it);
        }
      });
    });
  }

  function openMediaPreviewModal(item) {
    const url = `/api/files.php?action=preview&path=${encodeURIComponent(item.path)}`;
    const ext = item.extension;
    let bodyHtml = '';

    if (IMG_EXTS.has(ext)) {
      bodyHtml = `<img src="${url}" alt="${escapeHtml(item.name)}" style="max-width:100%;max-height:65vh;margin:0 auto;border-radius:10px;object-fit:contain;">`;
    } else if (ext === 'pdf') {
      bodyHtml = `<iframe src="${url}" style="width:100%;height:68vh;border:none;border-radius:10px;background:#FFF;"></iframe>`;
    } else if (VIDEO_EXTS.has(ext)) {
      bodyHtml = `<video src="${url}" controls autoplay style="width:100%;max-height:65vh;border-radius:10px;background:#000;"></video>`;
    } else if (AUDIO_EXTS.has(ext)) {
      bodyHtml = `<audio src="${url}" controls autoplay style="width:100%;margin:20px 0;"></audio>`;
    }

    modalSlot.innerHTML = `
      <div class="inwin-modal-backdrop">
        <div class="inwin-modal">
          <div class="inwin-modal-header">
            <span>Aperçu — ${escapeHtml(item.name)}</span>
            <div style="display:flex;gap:8px;">
              <a href="/api/files.php?action=download&path=${encodeURIComponent(item.path)}" class="btn-xs primary" style="text-decoration:none;">⬇️ Télécharger</a>
              <button type="button" class="btn-xs" id="closePrevModal">Fermer</button>
            </div>
          </div>
          <div class="inwin-modal-body">${bodyHtml}</div>
        </div>
      </div>
    `;
    modalSlot.querySelector('#closePrevModal').addEventListener('click', () => { modalSlot.innerHTML = ''; });
  }

  function openPermsModal(item) {
    modalSlot.innerHTML = `
      <div class="inwin-modal-backdrop">
        <div class="inwin-modal" style="max-width:440px;">
          <div class="inwin-modal-header">
            <span>🔐 Permissions UNIX — ${escapeHtml(item.name)}</span>
            <button type="button" class="btn-xs" id="closePermsModal">Fermer</button>
          </div>
          <div class="inwin-modal-body">
            <form id="permsForm">
              <div class="form-group">
                <label class="form-label">Mode Octal (chmod)</label>
                <input type="text" class="os-input" name="mode" value="${escapeHtml(item.mode)}" pattern="[0-7]{3,4}" required style="font-family:var(--font-mono);">
              </div>
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
                <div class="form-group">
                  <label class="form-label">Propriétaire (chown)</label>
                  <input type="text" class="os-input" name="owner" value="${escapeHtml(item.owner)}" required>
                </div>
                <div class="form-group">
                  <label class="form-label">Groupe</label>
                  <input type="text" class="os-input" name="group" value="${escapeHtml(item.group)}">
                </div>
              </div>
              ${item.is_dir ? `
                <div class="form-group">
                  <label style="display:flex;align-items:center;gap:8px;font-size:0.83rem;cursor:pointer;">
                    <input type="checkbox" name="recursive"> Appliquer récursivement (-R) au contenu du dossier
                  </label>
                </div>
              ` : ''}
              <button type="submit" class="os-btn os-btn-primary">Appliquer chmod & chown</button>
            </form>
          </div>
        </div>
      </div>
    `;

    modalSlot.querySelector('#closePermsModal').addEventListener('click', () => { modalSlot.innerHTML = ''; });
    modalSlot.querySelector('#permsForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData(e.currentTarget);
      const recursive = fd.get('recursive') === 'on';
      try {
        await api.post('/api/files.php?action=chmod', { path: item.path, mode: fd.get('mode'), recursive });
        await api.post('/api/files.php?action=chown', { path: item.path, owner: fd.get('owner'), group: fd.get('group'), recursive });
        modalSlot.innerHTML = '';
        notify('Permissions mises à jour.');
        await navigate(currentPath);
      } catch (err) {
        notify(err.message, 'error');
      }
    });
  }

  await navigate(currentPath);

  return {
    onLaunch(newParams) {
      if (newParams?.path) navigate(newParams.path);
    },
  };
}
